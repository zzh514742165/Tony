#!/usr/bin/env python
# -*- encoding: utf-8 -*-
'''
@文件    :middleware.py
@说明    :中间件
@时间    :2023/04/22 18:17:25
@作者    :郑哲昊
@版本    :1.0
'''
from baykeshop.models.user import BaykeUser


class CreateUserInfoMiddleware:
    """
    一对一关联用户默认关联中间件
    """
    
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):

        if request.user.is_authenticated:
            try:
                request.user.baykeuser
            except BaykeUser.DoesNotExist:
                BaykeUser.objects.create(owner=request.user)
                
        response = self.get_response(request)
        
        return response
