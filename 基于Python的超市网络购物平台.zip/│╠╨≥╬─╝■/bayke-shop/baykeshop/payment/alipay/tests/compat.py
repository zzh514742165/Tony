#!/usr/bin/env python
# coding: utf-8
"""
    compat.py
    ~~~~~~~~~~
"""
from unittest import mock
