#!/usr/bin/env python
# coding: utf-8
"""
    compat.py
    ~~~~~~~~~~
"""
from urllib.parse import quote_plus
from urllib.request import urlopen
from base64 import decodebytes, encodebytes
