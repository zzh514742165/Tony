/*
 Navicat MySQL Data Transfer

 Source Server         : shop
 Source Server Type    : MySQL
 Source Server Version : 80018
 Source Host           : localhost:3306
 Source Schema         : baykedb

 Target Server Type    : MySQL
 Target Server Version : 80018
 File Encoding         : 65001

 Date: 21/05/2023 16:27:07
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for auth_group
-- ----------------------------
DROP TABLE IF EXISTS `auth_group`;
CREATE TABLE `auth_group`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `name`(`name`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of auth_group
-- ----------------------------

-- ----------------------------
-- Table structure for auth_group_permissions
-- ----------------------------
DROP TABLE IF EXISTS `auth_group_permissions`;
CREATE TABLE `auth_group_permissions`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `auth_group_permissions_group_id_permission_id_0cd325b0_uniq`(`group_id`, `permission_id`) USING BTREE,
  INDEX `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm`(`permission_id`) USING BTREE,
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of auth_group_permissions
-- ----------------------------

-- ----------------------------
-- Table structure for auth_permission
-- ----------------------------
DROP TABLE IF EXISTS `auth_permission`;
CREATE TABLE `auth_permission`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `auth_permission_content_type_id_codename_01ab375a_uniq`(`content_type_id`, `codename`) USING BTREE,
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 145 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of auth_permission
-- ----------------------------
INSERT INTO `auth_permission` VALUES (1, 'Can add log entry', 1, 'add_logentry');
INSERT INTO `auth_permission` VALUES (2, 'Can change log entry', 1, 'change_logentry');
INSERT INTO `auth_permission` VALUES (3, 'Can delete log entry', 1, 'delete_logentry');
INSERT INTO `auth_permission` VALUES (4, 'Can view log entry', 1, 'view_logentry');
INSERT INTO `auth_permission` VALUES (5, 'Can add permission', 2, 'add_permission');
INSERT INTO `auth_permission` VALUES (6, 'Can change permission', 2, 'change_permission');
INSERT INTO `auth_permission` VALUES (7, 'Can delete permission', 2, 'delete_permission');
INSERT INTO `auth_permission` VALUES (8, 'Can view permission', 2, 'view_permission');
INSERT INTO `auth_permission` VALUES (9, 'Can add group', 3, 'add_group');
INSERT INTO `auth_permission` VALUES (10, 'Can change group', 3, 'change_group');
INSERT INTO `auth_permission` VALUES (11, 'Can delete group', 3, 'delete_group');
INSERT INTO `auth_permission` VALUES (12, 'Can view group', 3, 'view_group');
INSERT INTO `auth_permission` VALUES (13, 'Can add user', 4, 'add_user');
INSERT INTO `auth_permission` VALUES (14, 'Can change user', 4, 'change_user');
INSERT INTO `auth_permission` VALUES (15, 'Can delete user', 4, 'delete_user');
INSERT INTO `auth_permission` VALUES (16, 'Can view user', 4, 'view_user');
INSERT INTO `auth_permission` VALUES (17, 'Can add content type', 5, 'add_contenttype');
INSERT INTO `auth_permission` VALUES (18, 'Can change content type', 5, 'change_contenttype');
INSERT INTO `auth_permission` VALUES (19, 'Can delete content type', 5, 'delete_contenttype');
INSERT INTO `auth_permission` VALUES (20, 'Can view content type', 5, 'view_contenttype');
INSERT INTO `auth_permission` VALUES (21, 'Can add session', 6, 'add_session');
INSERT INTO `auth_permission` VALUES (22, 'Can change session', 6, 'change_session');
INSERT INTO `auth_permission` VALUES (23, 'Can delete session', 6, 'delete_session');
INSERT INTO `auth_permission` VALUES (24, 'Can view session', 6, 'view_session');
INSERT INTO `auth_permission` VALUES (25, 'Can add site', 7, 'add_site');
INSERT INTO `auth_permission` VALUES (26, 'Can change site', 7, 'change_site');
INSERT INTO `auth_permission` VALUES (27, 'Can delete site', 7, 'delete_site');
INSERT INTO `auth_permission` VALUES (28, 'Can view site', 7, 'view_site');
INSERT INTO `auth_permission` VALUES (29, 'Can add flat page', 8, 'add_flatpage');
INSERT INTO `auth_permission` VALUES (30, 'Can change flat page', 8, 'change_flatpage');
INSERT INTO `auth_permission` VALUES (31, 'Can delete flat page', 8, 'delete_flatpage');
INSERT INTO `auth_permission` VALUES (32, 'Can view flat page', 8, 'view_flatpage');
INSERT INTO `auth_permission` VALUES (33, 'Can add 菜单', 9, 'add_baykemenu');
INSERT INTO `auth_permission` VALUES (34, 'Can change 菜单', 9, 'change_baykemenu');
INSERT INTO `auth_permission` VALUES (35, 'Can delete 菜单', 9, 'delete_baykemenu');
INSERT INTO `auth_permission` VALUES (36, 'Can view 菜单', 9, 'view_baykemenu');
INSERT INTO `auth_permission` VALUES (37, 'Can add BaykeOrder', 10, 'add_baykeorder');
INSERT INTO `auth_permission` VALUES (38, 'Can change BaykeOrder', 10, 'change_baykeorder');
INSERT INTO `auth_permission` VALUES (39, 'Can delete BaykeOrder', 10, 'delete_baykeorder');
INSERT INTO `auth_permission` VALUES (40, 'Can view BaykeOrder', 10, 'view_baykeorder');
INSERT INTO `auth_permission` VALUES (41, 'Can add BaykeProductCategory', 11, 'add_baykeproductcategory');
INSERT INTO `auth_permission` VALUES (42, 'Can change BaykeProductCategory', 11, 'change_baykeproductcategory');
INSERT INTO `auth_permission` VALUES (43, 'Can delete BaykeProductCategory', 11, 'delete_baykeproductcategory');
INSERT INTO `auth_permission` VALUES (44, 'Can view BaykeProductCategory', 11, 'view_baykeproductcategory');
INSERT INTO `auth_permission` VALUES (45, 'Can add BaykeProductSpec', 12, 'add_baykeproductspec');
INSERT INTO `auth_permission` VALUES (46, 'Can change BaykeProductSpec', 12, 'change_baykeproductspec');
INSERT INTO `auth_permission` VALUES (47, 'Can delete BaykeProductSpec', 12, 'delete_baykeproductspec');
INSERT INTO `auth_permission` VALUES (48, 'Can view BaykeProductSpec', 12, 'view_baykeproductspec');
INSERT INTO `auth_permission` VALUES (49, 'Can add VerifyCode', 13, 'add_baykeverifycode');
INSERT INTO `auth_permission` VALUES (50, 'Can change VerifyCode', 13, 'change_baykeverifycode');
INSERT INTO `auth_permission` VALUES (51, 'Can delete VerifyCode', 13, 'delete_baykeverifycode');
INSERT INTO `auth_permission` VALUES (52, 'Can view VerifyCode', 13, 'view_baykeverifycode');
INSERT INTO `auth_permission` VALUES (53, 'Can add 余额明细', 14, 'add_baykeuserbalancelog');
INSERT INTO `auth_permission` VALUES (54, 'Can change 余额明细', 14, 'change_baykeuserbalancelog');
INSERT INTO `auth_permission` VALUES (55, 'Can delete 余额明细', 14, 'delete_baykeuserbalancelog');
INSERT INTO `auth_permission` VALUES (56, 'Can view 余额明细', 14, 'view_baykeuserbalancelog');
INSERT INTO `auth_permission` VALUES (57, 'Can add BaykeUser', 15, 'add_baykeuser');
INSERT INTO `auth_permission` VALUES (58, 'Can change BaykeUser', 15, 'change_baykeuser');
INSERT INTO `auth_permission` VALUES (59, 'Can delete BaykeUser', 15, 'delete_baykeuser');
INSERT INTO `auth_permission` VALUES (60, 'Can view BaykeUser', 15, 'view_baykeuser');
INSERT INTO `auth_permission` VALUES (61, 'Can add 富文本编辑器图片上传', 16, 'add_baykeupload');
INSERT INTO `auth_permission` VALUES (62, 'Can change 富文本编辑器图片上传', 16, 'change_baykeupload');
INSERT INTO `auth_permission` VALUES (63, 'Can delete 富文本编辑器图片上传', 16, 'delete_baykeupload');
INSERT INTO `auth_permission` VALUES (64, 'Can view 富文本编辑器图片上传', 16, 'view_baykeupload');
INSERT INTO `auth_permission` VALUES (65, 'Can add BaykeSite', 17, 'add_baykesite');
INSERT INTO `auth_permission` VALUES (66, 'Can change BaykeSite', 17, 'change_baykesite');
INSERT INTO `auth_permission` VALUES (67, 'Can delete BaykeSite', 17, 'delete_baykesite');
INSERT INTO `auth_permission` VALUES (68, 'Can view BaykeSite', 17, 'view_baykesite');
INSERT INTO `auth_permission` VALUES (69, 'Can add BaykeSpu', 18, 'add_baykeproductspu');
INSERT INTO `auth_permission` VALUES (70, 'Can change BaykeSpu', 18, 'change_baykeproductspu');
INSERT INTO `auth_permission` VALUES (71, 'Can delete BaykeSpu', 18, 'delete_baykeproductspu');
INSERT INTO `auth_permission` VALUES (72, 'Can view BaykeSpu', 18, 'view_baykeproductspu');
INSERT INTO `auth_permission` VALUES (73, 'Can add BaykeProductSpecOption', 19, 'add_baykeproductspecoption');
INSERT INTO `auth_permission` VALUES (74, 'Can change BaykeProductSpecOption', 19, 'change_baykeproductspecoption');
INSERT INTO `auth_permission` VALUES (75, 'Can delete BaykeProductSpecOption', 19, 'delete_baykeproductspecoption');
INSERT INTO `auth_permission` VALUES (76, 'Can view BaykeProductSpecOption', 19, 'view_baykeproductspecoption');
INSERT INTO `auth_permission` VALUES (77, 'Can add BaykeProductSKU', 20, 'add_baykeproductsku');
INSERT INTO `auth_permission` VALUES (78, 'Can change BaykeProductSKU', 20, 'change_baykeproductsku');
INSERT INTO `auth_permission` VALUES (79, 'Can delete BaykeProductSKU', 20, 'delete_baykeproductsku');
INSERT INTO `auth_permission` VALUES (80, 'Can view BaykeProductSKU', 20, 'view_baykeproductsku');
INSERT INTO `auth_permission` VALUES (81, 'Can add BaykeProductBanner', 21, 'add_baykeproductbanner');
INSERT INTO `auth_permission` VALUES (82, 'Can change BaykeProductBanner', 21, 'change_baykeproductbanner');
INSERT INTO `auth_permission` VALUES (83, 'Can delete BaykeProductBanner', 21, 'delete_baykeproductbanner');
INSERT INTO `auth_permission` VALUES (84, 'Can view BaykeProductBanner', 21, 'view_baykeproductbanner');
INSERT INTO `auth_permission` VALUES (85, 'Can add 菜单权限', 22, 'add_baykepermission');
INSERT INTO `auth_permission` VALUES (86, 'Can change 菜单权限', 22, 'change_baykepermission');
INSERT INTO `auth_permission` VALUES (87, 'Can delete 菜单权限', 22, 'delete_baykepermission');
INSERT INTO `auth_permission` VALUES (88, 'Can view 菜单权限', 22, 'view_baykepermission');
INSERT INTO `auth_permission` VALUES (89, 'Can add BaykeOrderSKU', 23, 'add_baykeordersku');
INSERT INTO `auth_permission` VALUES (90, 'Can change BaykeOrderSKU', 23, 'change_baykeordersku');
INSERT INTO `auth_permission` VALUES (91, 'Can delete BaykeOrderSKU', 23, 'delete_baykeordersku');
INSERT INTO `auth_permission` VALUES (92, 'Can view BaykeOrderSKU', 23, 'view_baykeordersku');
INSERT INTO `auth_permission` VALUES (93, 'Can add 商品评价', 24, 'add_baykeordercomments');
INSERT INTO `auth_permission` VALUES (94, 'Can change 商品评价', 24, 'change_baykeordercomments');
INSERT INTO `auth_permission` VALUES (95, 'Can delete 商品评价', 24, 'delete_baykeordercomments');
INSERT INTO `auth_permission` VALUES (96, 'Can view 商品评价', 24, 'view_baykeordercomments');
INSERT INTO `auth_permission` VALUES (97, 'Can add BaykeCart', 25, 'add_baykecart');
INSERT INTO `auth_permission` VALUES (98, 'Can change BaykeCart', 25, 'change_baykecart');
INSERT INTO `auth_permission` VALUES (99, 'Can delete BaykeCart', 25, 'delete_baykecart');
INSERT INTO `auth_permission` VALUES (100, 'Can view BaykeCart', 25, 'view_baykecart');
INSERT INTO `auth_permission` VALUES (101, 'Can add 轮播图', 26, 'add_baykebanner');
INSERT INTO `auth_permission` VALUES (102, 'Can change 轮播图', 26, 'change_baykebanner');
INSERT INTO `auth_permission` VALUES (103, 'Can delete 轮播图', 26, 'delete_baykebanner');
INSERT INTO `auth_permission` VALUES (104, 'Can view 轮播图', 26, 'view_baykebanner');
INSERT INTO `auth_permission` VALUES (105, 'Can add BaykeArticleTag', 27, 'add_baykearticletag');
INSERT INTO `auth_permission` VALUES (106, 'Can change BaykeArticleTag', 27, 'change_baykearticletag');
INSERT INTO `auth_permission` VALUES (107, 'Can delete BaykeArticleTag', 27, 'delete_baykearticletag');
INSERT INTO `auth_permission` VALUES (108, 'Can view BaykeArticleTag', 27, 'view_baykearticletag');
INSERT INTO `auth_permission` VALUES (109, 'Can add BaykeArticleCategory', 28, 'add_baykearticlecategory');
INSERT INTO `auth_permission` VALUES (110, 'Can change BaykeArticleCategory', 28, 'change_baykearticlecategory');
INSERT INTO `auth_permission` VALUES (111, 'Can delete BaykeArticleCategory', 28, 'delete_baykearticlecategory');
INSERT INTO `auth_permission` VALUES (112, 'Can view BaykeArticleCategory', 28, 'view_baykearticlecategory');
INSERT INTO `auth_permission` VALUES (113, 'Can add BaykeArticle', 29, 'add_baykearticle');
INSERT INTO `auth_permission` VALUES (114, 'Can change BaykeArticle', 29, 'change_baykearticle');
INSERT INTO `auth_permission` VALUES (115, 'Can delete BaykeArticle', 29, 'delete_baykearticle');
INSERT INTO `auth_permission` VALUES (116, 'Can view BaykeArticle', 29, 'view_baykearticle');
INSERT INTO `auth_permission` VALUES (117, 'Can add 收货地址', 30, 'add_baykeaddress');
INSERT INTO `auth_permission` VALUES (118, 'Can change 收货地址', 30, 'change_baykeaddress');
INSERT INTO `auth_permission` VALUES (119, 'Can delete 收货地址', 30, 'delete_baykeaddress');
INSERT INTO `auth_permission` VALUES (120, 'Can view 收货地址', 30, 'view_baykeaddress');
INSERT INTO `auth_permission` VALUES (121, 'Can add Bookmark', 31, 'add_bookmark');
INSERT INTO `auth_permission` VALUES (122, 'Can change Bookmark', 31, 'change_bookmark');
INSERT INTO `auth_permission` VALUES (123, 'Can delete Bookmark', 31, 'delete_bookmark');
INSERT INTO `auth_permission` VALUES (124, 'Can view Bookmark', 31, 'view_bookmark');
INSERT INTO `auth_permission` VALUES (125, 'Can add User Setting', 32, 'add_usersettings');
INSERT INTO `auth_permission` VALUES (126, 'Can change User Setting', 32, 'change_usersettings');
INSERT INTO `auth_permission` VALUES (127, 'Can delete User Setting', 32, 'delete_usersettings');
INSERT INTO `auth_permission` VALUES (128, 'Can view User Setting', 32, 'view_usersettings');
INSERT INTO `auth_permission` VALUES (129, 'Can add User Widget', 33, 'add_userwidget');
INSERT INTO `auth_permission` VALUES (130, 'Can change User Widget', 33, 'change_userwidget');
INSERT INTO `auth_permission` VALUES (131, 'Can delete User Widget', 33, 'delete_userwidget');
INSERT INTO `auth_permission` VALUES (132, 'Can view User Widget', 33, 'view_userwidget');
INSERT INTO `auth_permission` VALUES (133, 'Can add log entry', 34, 'add_log');
INSERT INTO `auth_permission` VALUES (134, 'Can change log entry', 34, 'change_log');
INSERT INTO `auth_permission` VALUES (135, 'Can delete log entry', 34, 'delete_log');
INSERT INTO `auth_permission` VALUES (136, 'Can view log entry', 34, 'view_log');
INSERT INTO `auth_permission` VALUES (137, 'Can add revision', 35, 'add_revision');
INSERT INTO `auth_permission` VALUES (138, 'Can change revision', 35, 'change_revision');
INSERT INTO `auth_permission` VALUES (139, 'Can delete revision', 35, 'delete_revision');
INSERT INTO `auth_permission` VALUES (140, 'Can view revision', 35, 'view_revision');
INSERT INTO `auth_permission` VALUES (141, 'Can add version', 36, 'add_version');
INSERT INTO `auth_permission` VALUES (142, 'Can change version', 36, 'change_version');
INSERT INTO `auth_permission` VALUES (143, 'Can delete version', 36, 'delete_version');
INSERT INTO `auth_permission` VALUES (144, 'Can view version', 36, 'view_version');

-- ----------------------------
-- Table structure for auth_user
-- ----------------------------
DROP TABLE IF EXISTS `auth_user`;
CREATE TABLE `auth_user`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `last_login` datetime(6) NULL DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `first_name` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `last_name` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `email` varchar(254) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `username`(`username`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of auth_user
-- ----------------------------
INSERT INTO `auth_user` VALUES (1, 'pbkdf2_sha256$600000$Wu3W1TzP6qBD6n3wQPX4NL$6wQUGH2PZJGpVR/XsJUMdN+7Ow5ImHb6Xo+iyJFmfnM=', '2023-05-19 07:06:56.459567', 1, 'admin', '', '', '7777777@qq.com', 1, 1, '2023-05-16 15:50:28.590394');
INSERT INTO `auth_user` VALUES (2, 'pbkdf2_sha256$600000$T2jiVxo1ItMnYbfgbNzbMF$kghentDX3IjghAN/JC7yn85VOH/8teYU4m1zBmyhtCQ=', '2023-05-19 06:30:51.234813', 0, 'testuser', '', '', '', 0, 1, '2023-05-19 02:05:00.000000');
INSERT INTO `auth_user` VALUES (3, 'pbkdf2_sha256$600000$6tsLF2cUTTchw1DmXbWPKW$0/UPvto1eCN1OovPm1J3dYBjnzMkbY64F+bSIG7zvro=', '2023-05-21 07:13:00.000000', 1, 'adm', '', '', '796433246@qq.com', 1, 1, '2023-05-20 08:50:00.000000');

-- ----------------------------
-- Table structure for auth_user_groups
-- ----------------------------
DROP TABLE IF EXISTS `auth_user_groups`;
CREATE TABLE `auth_user_groups`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `auth_user_groups_user_id_group_id_94350c0c_uniq`(`user_id`, `group_id`) USING BTREE,
  INDEX `auth_user_groups_group_id_97559544_fk_auth_group_id`(`group_id`) USING BTREE,
  CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of auth_user_groups
-- ----------------------------

-- ----------------------------
-- Table structure for auth_user_user_permissions
-- ----------------------------
DROP TABLE IF EXISTS `auth_user_user_permissions`;
CREATE TABLE `auth_user_user_permissions`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq`(`user_id`, `permission_id`) USING BTREE,
  INDEX `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm`(`permission_id`) USING BTREE,
  CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of auth_user_user_permissions
-- ----------------------------

-- ----------------------------
-- Table structure for baykeshop_baykeaddress
-- ----------------------------
DROP TABLE IF EXISTS `baykeshop_baykeaddress`;
CREATE TABLE `baykeshop_baykeaddress`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `add_date` datetime(6) NOT NULL,
  `pub_date` datetime(6) NOT NULL,
  `is_del` tinyint(1) NOT NULL,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `phone` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `email` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `province` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `city` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `county` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `address` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `is_default` tinyint(1) NOT NULL,
  `owner_id` int(11) NOT NULL,
  `site_id` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `baykeshop_baykeaddress_owner_id_7728f157_fk_auth_user_id`(`owner_id`) USING BTREE,
  INDEX `baykeshop_baykeaddress_site_id_7f84516e_fk_django_site_id`(`site_id`) USING BTREE,
  CONSTRAINT `baykeshop_baykeaddress_owner_id_7728f157_fk_auth_user_id` FOREIGN KEY (`owner_id`) REFERENCES `auth_user` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `baykeshop_baykeaddress_site_id_7f84516e_fk_django_site_id` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of baykeshop_baykeaddress
-- ----------------------------
INSERT INTO `baykeshop_baykeaddress` VALUES (1, '2023-05-19 02:15:29.148305', '2023-05-19 02:15:29.148305', 0, '黄守鼎', '18212205647', '', '北京市', '海淀区', '海淀区', '海淀区中关村', 1, 2, NULL);
INSERT INTO `baykeshop_baykeaddress` VALUES (2, '2023-05-21 07:57:47.442519', '2023-05-21 07:57:57.641307', 0, 'ada', '18646625675', '', 'wewqeqw', 'qweqw', 'qweqw', 'qweqw', 1, 3, NULL);

-- ----------------------------
-- Table structure for baykeshop_baykearticle
-- ----------------------------
DROP TABLE IF EXISTS `baykeshop_baykearticle`;
CREATE TABLE `baykeshop_baykearticle`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `add_date` datetime(6) NOT NULL,
  `pub_date` datetime(6) NOT NULL,
  `is_del` tinyint(1) NOT NULL,
  `title` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `desc` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `keywords` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `content` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `category_id` bigint(20) NOT NULL,
  `site_id` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `baykeshop_baykeartic_category_id_32ebe339_fk_baykeshop`(`category_id`) USING BTREE,
  INDEX `baykeshop_baykearticle_site_id_3a79d725_fk_django_site_id`(`site_id`) USING BTREE,
  CONSTRAINT `baykeshop_baykeartic_category_id_32ebe339_fk_baykeshop` FOREIGN KEY (`category_id`) REFERENCES `baykeshop_baykearticlecategory` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `baykeshop_baykearticle_site_id_3a79d725_fk_django_site_id` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of baykeshop_baykearticle
-- ----------------------------
INSERT INTO `baykeshop_baykearticle` VALUES (1, '2023-05-15 12:20:12.575000', '2023-05-16 03:00:03.027000', 0, '测试文章内容', '测试文章内容', '测试文章内容', '<p>测试文章内容测试文章内容测试文章内容测试文章内容测试文章内容测试文章内容测试文章内容测试文章内容测试文章内容测试文章内容测试文章内容测试文章内容测试文章内容测试文章内容测试文章内容测试文章内容测试文章内容测试文章内容测试文章内容测试文章内容测试文章内容测试文章内容测试文章内容测试文章内容</p>\r\n<p><img src=\"../../../../../media/upload/665e0b6abc22492883583511390e2583.jpg\" alt=\"\" width=\"800\" height=\"800\"></p>', 1, NULL);

-- ----------------------------
-- Table structure for baykeshop_baykearticle_tags
-- ----------------------------
DROP TABLE IF EXISTS `baykeshop_baykearticle_tags`;
CREATE TABLE `baykeshop_baykearticle_tags`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `baykearticle_id` bigint(20) NOT NULL,
  `baykearticletag_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `baykeshop_baykearticle_t_baykearticle_id_baykeart_f5df53e9_uniq`(`baykearticle_id`, `baykearticletag_id`) USING BTREE,
  INDEX `baykeshop_baykeartic_baykearticletag_id_7de9dc93_fk_baykeshop`(`baykearticletag_id`) USING BTREE,
  CONSTRAINT `baykeshop_baykeartic_baykearticle_id_590c761c_fk_baykeshop` FOREIGN KEY (`baykearticle_id`) REFERENCES `baykeshop_baykearticle` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `baykeshop_baykeartic_baykearticletag_id_7de9dc93_fk_baykeshop` FOREIGN KEY (`baykearticletag_id`) REFERENCES `baykeshop_baykearticletag` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of baykeshop_baykearticle_tags
-- ----------------------------
INSERT INTO `baykeshop_baykearticle_tags` VALUES (1, 1, 1);

-- ----------------------------
-- Table structure for baykeshop_baykearticlecategory
-- ----------------------------
DROP TABLE IF EXISTS `baykeshop_baykearticlecategory`;
CREATE TABLE `baykeshop_baykearticlecategory`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `add_date` datetime(6) NOT NULL,
  `pub_date` datetime(6) NOT NULL,
  `is_del` tinyint(1) NOT NULL,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `icon` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `desc` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `keywords` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `site_id` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `baykeshop_baykeartic_site_id_f5449545_fk_django_si`(`site_id`) USING BTREE,
  CONSTRAINT `baykeshop_baykeartic_site_id_f5449545_fk_django_si` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of baykeshop_baykearticlecategory
-- ----------------------------
INSERT INTO `baykeshop_baykearticlecategory` VALUES (1, '2023-05-15 12:19:02.739000', '2023-05-15 12:19:02.739000', 0, '商品资讯', '', '', '', NULL);

-- ----------------------------
-- Table structure for baykeshop_baykearticletag
-- ----------------------------
DROP TABLE IF EXISTS `baykeshop_baykearticletag`;
CREATE TABLE `baykeshop_baykearticletag`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `add_date` datetime(6) NOT NULL,
  `pub_date` datetime(6) NOT NULL,
  `is_del` tinyint(1) NOT NULL,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `site_id` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `baykeshop_baykearticletag_site_id_1ba297c6_fk_django_site_id`(`site_id`) USING BTREE,
  CONSTRAINT `baykeshop_baykearticletag_site_id_1ba297c6_fk_django_site_id` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of baykeshop_baykearticletag
-- ----------------------------
INSERT INTO `baykeshop_baykearticletag` VALUES (1, '2023-05-15 12:19:55.828000', '2023-05-15 12:19:55.828000', 0, '购物', NULL);

-- ----------------------------
-- Table structure for baykeshop_baykebanner
-- ----------------------------
DROP TABLE IF EXISTS `baykeshop_baykebanner`;
CREATE TABLE `baykeshop_baykebanner`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `add_date` datetime(6) NOT NULL,
  `pub_date` datetime(6) NOT NULL,
  `is_del` tinyint(1) NOT NULL,
  `img` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `desc` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `place` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `target_url` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `sort` smallint(5) UNSIGNED NOT NULL,
  `site_id` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `place`(`place`) USING BTREE,
  INDEX `baykeshop_baykebanner_site_id_52f7a514_fk_django_site_id`(`site_id`) USING BTREE,
  CONSTRAINT `baykeshop_baykebanner_site_id_52f7a514_fk_django_site_id` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of baykeshop_baykebanner
-- ----------------------------
INSERT INTO `baykeshop_baykebanner` VALUES (3, '2023-05-17 02:39:50.753794', '2023-05-17 02:39:50.753794', 0, 'upload/2_zC7C4y7.jpg', '', NULL, '', 1, NULL);
INSERT INTO `baykeshop_baykebanner` VALUES (4, '2023-05-19 01:43:52.868203', '2023-05-19 01:43:52.868203', 0, 'upload/1_Jm1PD6a.jpg', '', NULL, '', 1, NULL);
INSERT INTO `baykeshop_baykebanner` VALUES (5, '2023-05-19 01:44:06.340640', '2023-05-19 01:44:06.340640', 0, 'upload/3_vakPJNZ.jpg', '', NULL, '', 1, NULL);

-- ----------------------------
-- Table structure for baykeshop_baykecart
-- ----------------------------
DROP TABLE IF EXISTS `baykeshop_baykecart`;
CREATE TABLE `baykeshop_baykecart`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `add_date` datetime(6) NOT NULL,
  `pub_date` datetime(6) NOT NULL,
  `is_del` tinyint(1) NOT NULL,
  `count` int(10) UNSIGNED NOT NULL,
  `owner_id` int(11) NOT NULL,
  `site_id` int(11) NULL DEFAULT NULL,
  `sku_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `unique_owner_sku`(`owner_id`, `sku_id`) USING BTREE,
  INDEX `baykeshop_baykecart_site_id_332cc0ad_fk_django_site_id`(`site_id`) USING BTREE,
  INDEX `baykeshop_baykecart_sku_id_c1bcb3c5_fk_baykeshop`(`sku_id`) USING BTREE,
  CONSTRAINT `baykeshop_baykecart_owner_id_a58e9974_fk_auth_user_id` FOREIGN KEY (`owner_id`) REFERENCES `auth_user` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `baykeshop_baykecart_site_id_332cc0ad_fk_django_site_id` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `baykeshop_baykecart_sku_id_c1bcb3c5_fk_baykeshop` FOREIGN KEY (`sku_id`) REFERENCES `baykeshop_baykeproductsku` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of baykeshop_baykecart
-- ----------------------------

-- ----------------------------
-- Table structure for baykeshop_baykemenu
-- ----------------------------
DROP TABLE IF EXISTS `baykeshop_baykemenu`;
CREATE TABLE `baykeshop_baykemenu`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `add_date` datetime(6) NOT NULL,
  `pub_date` datetime(6) NOT NULL,
  `is_del` tinyint(1) NOT NULL,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `icon` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `desc` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `keywords` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `sort` smallint(5) UNSIGNED NOT NULL,
  `site_id` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `baykeshop_baykemenu_site_id_f059054a_fk_django_site_id`(`site_id`) USING BTREE,
  CONSTRAINT `baykeshop_baykemenu_site_id_f059054a_fk_django_site_id` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of baykeshop_baykemenu
-- ----------------------------
INSERT INTO `baykeshop_baykemenu` VALUES (1, '2023-05-16 15:50:48.295469', '2023-05-16 15:50:48.295469', 0, '订单', '', '', '', 3, NULL);
INSERT INTO `baykeshop_baykemenu` VALUES (2, '2023-05-16 15:50:48.307437', '2023-05-16 15:50:48.307437', 0, '商品', '', '', '', 4, NULL);
INSERT INTO `baykeshop_baykemenu` VALUES (3, '2023-05-16 15:50:48.331373', '2023-05-16 15:50:48.331373', 0, '认证和授权', '', '', '', 1, NULL);
INSERT INTO `baykeshop_baykemenu` VALUES (4, '2023-05-16 15:50:48.353316', '2023-05-16 15:50:48.353316', 0, '内容', '', '', '', 2, NULL);

-- ----------------------------
-- Table structure for baykeshop_baykeorder
-- ----------------------------
DROP TABLE IF EXISTS `baykeshop_baykeorder`;
CREATE TABLE `baykeshop_baykeorder`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `add_date` datetime(6) NOT NULL,
  `pub_date` datetime(6) NOT NULL,
  `is_del` tinyint(1) NOT NULL,
  `order_sn` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `trade_sn` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `pay_status` int(11) NOT NULL,
  `pay_method` int(11) NULL DEFAULT NULL,
  `total_amount` decimal(12, 2) NOT NULL,
  `order_mark` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `phone` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `email` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `address` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `pay_time` datetime(6) NULL DEFAULT NULL,
  `owner_id` int(11) NOT NULL,
  `site_id` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `order_sn`(`order_sn`) USING BTREE,
  UNIQUE INDEX `trade_sn`(`trade_sn`) USING BTREE,
  INDEX `baykeshop_baykeorder_owner_id_39a34e78_fk_auth_user_id`(`owner_id`) USING BTREE,
  INDEX `baykeshop_baykeorder_site_id_d574258d_fk_django_site_id`(`site_id`) USING BTREE,
  CONSTRAINT `baykeshop_baykeorder_owner_id_39a34e78_fk_auth_user_id` FOREIGN KEY (`owner_id`) REFERENCES `auth_user` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `baykeshop_baykeorder_site_id_d574258d_fk_django_site_id` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of baykeshop_baykeorder
-- ----------------------------
INSERT INTO `baykeshop_baykeorder` VALUES (1, '2023-05-19 02:15:33.210419', '2023-05-19 02:21:17.166036', 0, '20230519021533294', NULL, 4, 4, 128.00, '', '黄守鼎', '18212205647', '', '北京市海淀区海淀区海淀区中关村', '2023-05-19 02:20:19.310027', 2, NULL);
INSERT INTO `baykeshop_baykeorder` VALUES (2, '2023-05-19 04:20:17.974494', '2023-05-19 04:20:22.778846', 0, '20230519042017212', NULL, 3, 4, 19.90, '', '黄守鼎', '18212205647', '', '北京市海淀区海淀区海淀区中关村', '2023-05-19 04:20:22.778846', 2, NULL);
INSERT INTO `baykeshop_baykeorder` VALUES (3, '2023-05-19 06:31:07.041237', '2023-05-19 06:31:09.559099', 0, '20230519063107242', NULL, 3, 4, 19.90, '', '黄守鼎', '18212205647', '', '北京市海淀区海淀区海淀区中关村', '2023-05-19 06:31:09.559099', 2, NULL);
INSERT INTO `baykeshop_baykeorder` VALUES (4, '2023-05-21 07:58:00.026175', '2023-05-21 07:58:05.447042', 0, '20230521075800336', NULL, 2, 4, 1379.00, '', 'ada', '18646625675', '', 'wewqeqwqweqwqweqwqweqw', '2023-05-21 07:58:05.447042', 3, NULL);

-- ----------------------------
-- Table structure for baykeshop_baykeordercomments
-- ----------------------------
DROP TABLE IF EXISTS `baykeshop_baykeordercomments`;
CREATE TABLE `baykeshop_baykeordercomments`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `add_date` datetime(6) NOT NULL,
  `pub_date` datetime(6) NOT NULL,
  `is_del` tinyint(1) NOT NULL,
  `object_id` int(10) UNSIGNED NULL DEFAULT NULL,
  `tag` varchar(80) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `content` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `comment_choices` smallint(5) UNSIGNED NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `owner_id` int(11) NOT NULL,
  `site_id` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `object_id`(`object_id`) USING BTREE,
  UNIQUE INDEX `tag`(`tag`) USING BTREE,
  INDEX `baykeshop_baykeorder_content_type_id_7a43d766_fk_django_co`(`content_type_id`) USING BTREE,
  INDEX `baykeshop_baykeordercomments_owner_id_93240f66_fk_auth_user_id`(`owner_id`) USING BTREE,
  INDEX `baykeshop_baykeordercomments_site_id_234d40a1_fk_django_site_id`(`site_id`) USING BTREE,
  CONSTRAINT `baykeshop_baykeorder_content_type_id_7a43d766_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `baykeshop_baykeordercomments_owner_id_93240f66_fk_auth_user_id` FOREIGN KEY (`owner_id`) REFERENCES `auth_user` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `baykeshop_baykeordercomments_site_id_234d40a1_fk_django_site_id` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of baykeshop_baykeordercomments
-- ----------------------------

-- ----------------------------
-- Table structure for baykeshop_baykeordersku
-- ----------------------------
DROP TABLE IF EXISTS `baykeshop_baykeordersku`;
CREATE TABLE `baykeshop_baykeordersku`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `add_date` datetime(6) NOT NULL,
  `pub_date` datetime(6) NOT NULL,
  `is_del` tinyint(1) NOT NULL,
  `title` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `options` json NOT NULL,
  `price` decimal(8, 2) NOT NULL,
  `content` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `count` int(11) NOT NULL,
  `is_commented` tinyint(1) NOT NULL,
  `order_id` bigint(20) NOT NULL,
  `site_id` int(11) NULL DEFAULT NULL,
  `sku_id` bigint(20) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `baykeshop_baykeorder_order_id_f8e22364_fk_baykeshop`(`order_id`) USING BTREE,
  INDEX `baykeshop_baykeordersku_site_id_bf8eb092_fk_django_site_id`(`site_id`) USING BTREE,
  INDEX `baykeshop_baykeorder_sku_id_4a99bdaf_fk_baykeshop`(`sku_id`) USING BTREE,
  CONSTRAINT `baykeshop_baykeorder_order_id_f8e22364_fk_baykeshop` FOREIGN KEY (`order_id`) REFERENCES `baykeshop_baykeorder` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `baykeshop_baykeorder_sku_id_4a99bdaf_fk_baykeshop` FOREIGN KEY (`sku_id`) REFERENCES `baykeshop_baykeproductsku` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `baykeshop_baykeordersku_site_id_bf8eb092_fk_django_site_id` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of baykeshop_baykeordersku
-- ----------------------------
INSERT INTO `baykeshop_baykeordersku` VALUES (1, '2023-05-19 02:15:33.223384', '2023-05-19 02:15:33.223384', 0, '测试的商品', '[]', 128.00, '测试的商品测试的商品测试的商品测试的商品测试的商品测试的商品测试的商品测试的商品测试的商品测试的商品测试的商品测试的商品测试的商品测试的商品测试的商品测试的商品测试的商品测试的商品', 1, 0, 1, NULL, 3);
INSERT INTO `baykeshop_baykeordersku` VALUES (2, '2023-05-19 04:20:17.988458', '2023-05-19 04:20:17.988458', 0, '三只松鼠牛肉干蜀香牛肉麻辣味100g*1袋零食解馋熟食特产小吃', '[]', 19.90, '<p class=\"Attrs--attrSection--2_G8xGa\"><span class=\"Attrs--attr--33ShB6X\" title=\"食品工艺：卤味\" data-spm-anchor-id=\"pc_detail.27183998/evo365560b447259evo401275b518001.202206.i0.26e57dd6AGBPDn\">食品工艺：卤味&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</span><span class=\"Attrs--attr--33ShB6X\" title=\"包装方式：包装\">包装方式：包装&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</span><span class=\"Attrs--attr--33ShB6X\" title=\"净含量：100g\">净含量：100g</span></p>\r\n<div class=\"Attrs--attrSection--2_G8xGa\"><span class=\"Attrs--attr--33ShB6X\" title=\"品牌：Three Squirrels/三只松鼠\">品牌：Three Squirrels/三只松鼠&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</span><span class=\"Attrs--attr--33ShB6X\" title=\"系列：三只松鼠麻辣牛肉\">系列：三只松鼠麻辣牛肉&nbsp; &nbsp; &nbsp;</span><span class=\"Attrs--attr--33ShB6X\" title=\"产地：中国大陆\">产地：中国大陆</span></div>\r\n<p class=\"Attrs--attrSection--2_G8xGa\"><span class=\"Attrs--attr--33ShB6X\" title=\"省份：四川省\">省份：四川省&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class=\"Attrs--attr--33ShB6X\" title=\"城市：乐山市\">城市：乐山市&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</span><span class=\"Attrs--attr--33ShB6X\" title=\"肉类产品：其他/other\">肉类产品：其他/other</span></p>\r\n<p class=\"Attrs--attrSection--2_G8xGa\"><span class=\"Attrs--attr--33ShB6X\" title=\"肉类产品：其他/other\"><img src=\"https://img.alicdn.com/imgextra/i4/880734502/O1CN015ZMwne1j7xpj5eMo8_!!880734502-0-scmitem6000.jpg\" alt=\"\" width=\"790\" height=\"1225\"></span></p>\r\n<p class=\"Attrs--attrSection--2_G8xGa\"><span class=\"Attrs--attr--33ShB6X\" title=\"肉类产品：其他/other\"><img src=\"https://img.alicdn.com/imgextra/i2/2200628041767/O1CN01tXv1hw1OvKaSz4vhD_!!2200628041767-0-scmitem6000.jpg\" alt=\"\" width=\"790\" height=\"1225\"></span></p>\r\n<p class=\"Attrs--attrSection--2_G8xGa\">&nbsp;</p>', 1, 0, 2, NULL, 8);
INSERT INTO `baykeshop_baykeordersku` VALUES (3, '2023-05-19 06:31:07.052172', '2023-05-19 06:31:07.052172', 0, '三只松鼠牛肉干蜀香牛肉麻辣味100g*1袋零食解馋熟食特产小吃', '[]', 19.90, '<p class=\"Attrs--attrSection--2_G8xGa\"><span class=\"Attrs--attr--33ShB6X\" title=\"食品工艺：卤味\" data-spm-anchor-id=\"pc_detail.27183998/evo365560b447259evo401275b518001.202206.i0.26e57dd6AGBPDn\">食品工艺：卤味&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</span><span class=\"Attrs--attr--33ShB6X\" title=\"包装方式：包装\">包装方式：包装&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</span><span class=\"Attrs--attr--33ShB6X\" title=\"净含量：100g\">净含量：100g</span></p>\r\n<div class=\"Attrs--attrSection--2_G8xGa\"><span class=\"Attrs--attr--33ShB6X\" title=\"品牌：Three Squirrels/三只松鼠\">品牌：Three Squirrels/三只松鼠&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</span><span class=\"Attrs--attr--33ShB6X\" title=\"系列：三只松鼠麻辣牛肉\">系列：三只松鼠麻辣牛肉&nbsp; &nbsp; &nbsp;</span><span class=\"Attrs--attr--33ShB6X\" title=\"产地：中国大陆\">产地：中国大陆</span></div>\r\n<p class=\"Attrs--attrSection--2_G8xGa\"><span class=\"Attrs--attr--33ShB6X\" title=\"省份：四川省\">省份：四川省&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class=\"Attrs--attr--33ShB6X\" title=\"城市：乐山市\">城市：乐山市&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</span><span class=\"Attrs--attr--33ShB6X\" title=\"肉类产品：其他/other\">肉类产品：其他/other</span></p>\r\n<p class=\"Attrs--attrSection--2_G8xGa\"><span class=\"Attrs--attr--33ShB6X\" title=\"肉类产品：其他/other\"><img src=\"https://img.alicdn.com/imgextra/i4/880734502/O1CN015ZMwne1j7xpj5eMo8_!!880734502-0-scmitem6000.jpg\" alt=\"\" width=\"790\" height=\"1225\"></span></p>\r\n<p class=\"Attrs--attrSection--2_G8xGa\"><span class=\"Attrs--attr--33ShB6X\" title=\"肉类产品：其他/other\"><img src=\"https://img.alicdn.com/imgextra/i2/2200628041767/O1CN01tXv1hw1OvKaSz4vhD_!!2200628041767-0-scmitem6000.jpg\" alt=\"\" width=\"790\" height=\"1225\"></span></p>\r\n<p class=\"Attrs--attrSection--2_G8xGa\">&nbsp;</p>', 1, 0, 3, NULL, 8);
INSERT INTO `baykeshop_baykeordersku` VALUES (4, '2023-05-21 07:58:00.040138', '2023-05-21 07:58:00.040138', 0, '德国ZBMJK全铜白色枪灰色热熔暗装预埋淋浴花洒冷热水按键数显', '[]', 1379.00, '<div class=\"Attrs--attrSection--2_G8xGa\"><span class=\"Attrs--attr--33ShB6X\" title=\"品牌：zBmJK\" data-spm-anchor-id=\"pc_detail.27183998/evo365560b447259evo401275b518001.202206.i0.69a27dd6EjxwyD\">品牌：zBmJK&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</span><span class=\"Attrs--attr--33ShB6X\" title=\"型号：HF9661\">型号：HF9661&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</span><span class=\"Attrs--attr--33ShB6X\" title=\"材质：全铜\">材质：全铜</span></div>\r\n<div class=\"Attrs--attrSection--2_G8xGa\"><span class=\"Attrs--attr--33ShB6X\" title=\"颜色分类：镀铬2功能数显 镀铬3功能数显 黑色2功能数显 黑色3功能数显 拉丝金2功能数显 拉丝金3功能数显 白色2功能数显 白色3功能数显 枪灰色2功能数显 枪灰色3功能数显\">颜色分类：镀铬2功能数显 镀铬3功能数显 黑色2功能数显 黑色3功能数显 拉丝金2功能数显 拉丝金3功能数显 白色2功能数显 白色3功能数显 枪灰色2功能数显 枪灰色3功能数显</span></div>\r\n<div class=\"Attrs--attrSection--2_G8xGa\"><span class=\"Attrs--attr--33ShB6X\" title=\"颜色分类：镀铬2功能数显 镀铬3功能数显 黑色2功能数显 黑色3功能数显 拉丝金2功能数显 拉丝金3功能数显 白色2功能数显 白色3功能数显 枪灰色2功能数显 枪灰色3功能数显\"><img src=\"https://img.alicdn.com/imgextra/i2/2214426167942/O1CN0113AYWf28XUMyl4DSG_!!2214426167942.jpg\" alt=\"\" width=\"1500\" height=\"2322\"></span></div>\r\n<div class=\"Attrs--attrSection--2_G8xGa\">&nbsp;</div>', 1, 0, 4, NULL, 9);

-- ----------------------------
-- Table structure for baykeshop_baykepermission
-- ----------------------------
DROP TABLE IF EXISTS `baykeshop_baykepermission`;
CREATE TABLE `baykeshop_baykepermission`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `add_date` datetime(6) NOT NULL,
  `pub_date` datetime(6) NOT NULL,
  `is_del` tinyint(1) NOT NULL,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `icon` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `desc` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `keywords` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `sort` smallint(5) UNSIGNED NOT NULL,
  `is_show` tinyint(1) NOT NULL,
  `menus_id` bigint(20) NOT NULL,
  `permission_id` int(11) NULL DEFAULT NULL,
  `site_id` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `permission_id`(`permission_id`) USING BTREE,
  INDEX `baykeshop_baykepermi_menus_id_0f07b3dd_fk_baykeshop`(`menus_id`) USING BTREE,
  INDEX `baykeshop_baykepermission_site_id_8dbb0375_fk_django_site_id`(`site_id`) USING BTREE,
  CONSTRAINT `baykeshop_baykepermi_menus_id_0f07b3dd_fk_baykeshop` FOREIGN KEY (`menus_id`) REFERENCES `baykeshop_baykemenu` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `baykeshop_baykepermi_permission_id_0dbf62fe_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `baykeshop_baykepermission_site_id_8dbb0375_fk_django_site_id` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 14 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of baykeshop_baykepermission
-- ----------------------------
INSERT INTO `baykeshop_baykepermission` VALUES (1, '2023-05-16 15:50:48.302450', '2023-05-16 15:50:48.302450', 0, '订单管理', '', '', '', 1, 1, 1, 40, NULL);
INSERT INTO `baykeshop_baykepermission` VALUES (2, '2023-05-16 15:50:48.313421', '2023-05-16 15:50:48.313421', 0, '商品分类', '', '', '', 1, 1, 2, 44, NULL);
INSERT INTO `baykeshop_baykepermission` VALUES (3, '2023-05-16 15:50:48.318408', '2023-05-16 15:50:48.318408', 0, '商品规格', '', '', '', 1, 1, 2, 48, NULL);
INSERT INTO `baykeshop_baykepermission` VALUES (4, '2023-05-16 15:50:48.323394', '2023-05-16 15:50:48.323394', 0, '商品管理', '', '', '', 1, 1, 2, 72, NULL);
INSERT INTO `baykeshop_baykepermission` VALUES (5, '2023-05-16 15:50:48.327384', '2023-05-16 15:50:48.327384', 0, '轮播图', '', '', '', 1, 1, 2, 104, NULL);
INSERT INTO `baykeshop_baykepermission` VALUES (6, '2023-05-16 15:50:48.335363', '2023-05-16 15:50:48.335363', 0, '组', '', '', '', 1, 1, 3, 12, NULL);
INSERT INTO `baykeshop_baykepermission` VALUES (7, '2023-05-16 15:50:48.340349', '2023-05-16 15:50:48.340349', 0, '用户', '', '', '', 1, 1, 3, 16, NULL);
INSERT INTO `baykeshop_baykepermission` VALUES (8, '2023-05-16 15:50:48.345336', '2023-05-16 15:50:48.345336', 0, '菜单', '', '', '', 1, 1, 3, 36, NULL);
INSERT INTO `baykeshop_baykepermission` VALUES (9, '2023-05-16 15:50:48.349326', '2023-05-16 15:50:48.349326', 0, '日志', '', '', '', 1, 1, 3, 4, NULL);
INSERT INTO `baykeshop_baykepermission` VALUES (10, '2023-05-16 15:50:48.358302', '2023-05-16 15:50:48.358302', 0, '文章分类', '', '', '', 1, 1, 4, 112, NULL);
INSERT INTO `baykeshop_baykepermission` VALUES (11, '2023-05-16 15:50:48.363288', '2023-05-16 15:50:48.363288', 0, '内容管理', '', '', '', 1, 1, 4, 116, NULL);
INSERT INTO `baykeshop_baykepermission` VALUES (12, '2023-05-16 15:50:48.368275', '2023-05-16 15:50:48.368275', 0, '单页管理', '', '', '', 1, 1, 4, 32, NULL);
INSERT INTO `baykeshop_baykepermission` VALUES (13, '2023-05-16 15:50:48.373261', '2023-05-16 15:50:48.373261', 0, '站点', '', '', '', 1, 1, 4, 28, NULL);

-- ----------------------------
-- Table structure for baykeshop_baykeproductbanner
-- ----------------------------
DROP TABLE IF EXISTS `baykeshop_baykeproductbanner`;
CREATE TABLE `baykeshop_baykeproductbanner`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `add_date` datetime(6) NOT NULL,
  `pub_date` datetime(6) NOT NULL,
  `is_del` tinyint(1) NOT NULL,
  `img` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `desc` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `site_id` int(11) NULL DEFAULT NULL,
  `spu_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `baykeshop_baykeproductbanner_site_id_62065798_fk_django_site_id`(`site_id`) USING BTREE,
  INDEX `baykeshop_baykeprodu_spu_id_be60b400_fk_baykeshop`(`spu_id`) USING BTREE,
  CONSTRAINT `baykeshop_baykeprodu_spu_id_be60b400_fk_baykeshop` FOREIGN KEY (`spu_id`) REFERENCES `baykeshop_baykeproductspu` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `baykeshop_baykeproductbanner_site_id_62065798_fk_django_site_id` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 23 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of baykeshop_baykeproductbanner
-- ----------------------------
INSERT INTO `baykeshop_baykeproductbanner` VALUES (3, '2023-05-15 08:12:53.631000', '2023-05-15 08:12:53.631000', 0, 'upload/e56244892796c5b8464b83bca60380b5.jpg', '', NULL, 2);
INSERT INTO `baykeshop_baykeproductbanner` VALUES (4, '2023-05-15 08:12:53.633000', '2023-05-15 08:12:53.633000', 0, 'upload/c58603a064d06392dd1453edcb0d6607_VHOzcX9.jpg', '', NULL, 2);
INSERT INTO `baykeshop_baykeproductbanner` VALUES (5, '2023-05-15 08:14:07.970000', '2023-05-15 08:14:07.970000', 0, 'upload/O1CN01G08Ojn1XLS3Ze6NWh_2200771672907.jpg', '', NULL, 3);
INSERT INTO `baykeshop_baykeproductbanner` VALUES (6, '2023-05-15 08:14:07.972000', '2023-05-15 08:14:07.972000', 0, 'upload/O1CN01UNdPv61XLS3eFeCp8_2200771672907.jpg', '', NULL, 3);
INSERT INTO `baykeshop_baykeproductbanner` VALUES (7, '2023-05-19 03:19:26.569858', '2023-05-19 03:26:38.460988', 0, 'upload/milk_WVSvioN.jpg', '', NULL, 4);
INSERT INTO `baykeshop_baykeproductbanner` VALUES (8, '2023-05-19 03:19:26.671171', '2023-05-19 03:26:11.650765', 0, 'upload/milk5_PABoPCN.jpg', '', NULL, 4);
INSERT INTO `baykeshop_baykeproductbanner` VALUES (9, '2023-05-19 03:22:45.254285', '2023-05-19 03:26:11.648742', 0, 'upload/milk4_BnqmX9B.jpg', '', NULL, 4);
INSERT INTO `baykeshop_baykeproductbanner` VALUES (10, '2023-05-19 03:35:17.195218', '2023-05-19 03:35:17.195218', 0, 'upload/巧克力_HDFOWhG.jpg', '', NULL, 5);
INSERT INTO `baykeshop_baykeproductbanner` VALUES (11, '2023-05-19 03:35:17.197225', '2023-05-19 03:35:17.197225', 0, 'upload/巧克力3_QVKUbi3.jpg', '', NULL, 5);
INSERT INTO `baykeshop_baykeproductbanner` VALUES (12, '2023-05-19 03:35:17.294089', '2023-05-19 03:35:17.294089', 0, 'upload/巧克力2_oNYs3kY.jpg', '', NULL, 5);
INSERT INTO `baykeshop_baykeproductbanner` VALUES (13, '2023-05-19 03:41:10.042457', '2023-05-19 03:41:10.042457', 0, 'upload/饼干_Yn7eJ3x.jpg', '', NULL, 6);
INSERT INTO `baykeshop_baykeproductbanner` VALUES (14, '2023-05-19 03:41:10.044486', '2023-05-19 03:41:10.044486', 0, 'upload/饼干2_5lhWbzV.jpg', '', NULL, 6);
INSERT INTO `baykeshop_baykeproductbanner` VALUES (15, '2023-05-19 03:41:10.133651', '2023-05-19 03:41:10.133651', 0, 'upload/饼干3_YpGKTIX.jpg', '', NULL, 6);
INSERT INTO `baykeshop_baykeproductbanner` VALUES (16, '2023-05-19 03:44:58.081084', '2023-05-19 03:44:58.081084', 0, 'upload/牛肉_25N7VSv.jpg', '', NULL, 7);
INSERT INTO `baykeshop_baykeproductbanner` VALUES (17, '2023-05-19 03:44:58.437811', '2023-05-19 03:44:58.437811', 0, 'upload/牛肉2_Tywp1VC.jpg', '', NULL, 7);
INSERT INTO `baykeshop_baykeproductbanner` VALUES (18, '2023-05-19 03:44:58.470750', '2023-05-19 03:44:58.470750', 0, 'upload/牛肉3_T7tHFlA.jpg', '', NULL, 7);
INSERT INTO `baykeshop_baykeproductbanner` VALUES (19, '2023-05-19 03:49:38.554021', '2023-05-19 03:49:38.554021', 0, 'upload/花洒_x5dFYSb.jpg', '', NULL, 8);
INSERT INTO `baykeshop_baykeproductbanner` VALUES (20, '2023-05-19 03:49:38.559007', '2023-05-19 03:49:38.559007', 0, 'upload/花洒2_uihe3Ft.jpg', '', NULL, 8);
INSERT INTO `baykeshop_baykeproductbanner` VALUES (21, '2023-05-19 03:49:38.560005', '2023-05-19 03:49:38.560005', 0, 'upload/花洒3_usRDqE2.jpg', '', NULL, 8);
INSERT INTO `baykeshop_baykeproductbanner` VALUES (22, '2023-05-19 03:49:38.562997', '2023-05-19 03:49:38.562997', 0, 'upload/花洒4_8SzOtNC.jpg', '', NULL, 8);

-- ----------------------------
-- Table structure for baykeshop_baykeproductcategory
-- ----------------------------
DROP TABLE IF EXISTS `baykeshop_baykeproductcategory`;
CREATE TABLE `baykeshop_baykeproductcategory`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `add_date` datetime(6) NOT NULL,
  `pub_date` datetime(6) NOT NULL,
  `is_del` tinyint(1) NOT NULL,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `icon` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `desc` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `keywords` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `pic` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `is_nav` tinyint(1) NOT NULL,
  `parent_id` bigint(20) NULL DEFAULT NULL,
  `site_id` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `baykeshop_baykeprodu_parent_id_38c8c6c5_fk_baykeshop`(`parent_id`) USING BTREE,
  INDEX `baykeshop_baykeprodu_site_id_70e1de29_fk_django_si`(`site_id`) USING BTREE,
  CONSTRAINT `baykeshop_baykeprodu_parent_id_38c8c6c5_fk_baykeshop` FOREIGN KEY (`parent_id`) REFERENCES `baykeshop_baykeproductcategory` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `baykeshop_baykeprodu_site_id_70e1de29_fk_django_si` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 14 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of baykeshop_baykeproductcategory
-- ----------------------------
INSERT INTO `baykeshop_baykeproductcategory` VALUES (1, '2023-04-28 05:41:39.189000', '2023-05-19 03:49:57.118412', 0, '家用电器', '', '', '', 'product/cate/123.png', 1, NULL, NULL);
INSERT INTO `baykeshop_baykeproductcategory` VALUES (2, '2023-04-28 05:41:39.193000', '2023-04-28 05:41:39.193000', 0, '扫地机', '', '', '', 'default/cate.png', 1, 1, NULL);
INSERT INTO `baykeshop_baykeproductcategory` VALUES (3, '2023-04-28 05:41:39.194000', '2023-04-28 05:41:39.194000', 0, '挂烫机', '', '', '', 'default/cate.png', 1, 1, NULL);
INSERT INTO `baykeshop_baykeproductcategory` VALUES (4, '2023-04-28 07:22:35.617000', '2023-04-28 07:22:35.617000', 0, '办公设备', '', '', '', 'product/cate/d2a316f8e8dd3b8ba4335c8197fb4ff2.png', 1, NULL, NULL);
INSERT INTO `baykeshop_baykeproductcategory` VALUES (5, '2023-04-28 07:22:35.620000', '2023-04-28 07:22:35.620000', 0, '电脑', '', '', '', 'default/cate.png', 1, 4, NULL);
INSERT INTO `baykeshop_baykeproductcategory` VALUES (6, '2023-04-28 07:22:35.621000', '2023-04-28 07:22:35.621000', 0, '打印机', '', '', '', 'default/cate.png', 1, 4, NULL);
INSERT INTO `baykeshop_baykeproductcategory` VALUES (7, '2023-04-28 07:22:35.621000', '2023-04-28 07:22:35.621000', 0, '打印纸', '', '', '', 'default/cate.png', 1, 4, NULL);
INSERT INTO `baykeshop_baykeproductcategory` VALUES (8, '2023-05-19 03:13:49.781535', '2023-05-19 03:13:49.781535', 0, '食品饮料', '', '食品饮料', '食品饮料', 'product/cate/milk.jpg', 1, NULL, NULL);
INSERT INTO `baykeshop_baykeproductcategory` VALUES (9, '2023-05-19 03:13:49.783530', '2023-05-19 03:13:49.783530', 0, '进口食品', '', '', '', 'default/cate.png', 1, 8, NULL);
INSERT INTO `baykeshop_baykeproductcategory` VALUES (10, '2023-05-19 03:13:49.784527', '2023-05-19 03:13:49.784527', 0, '肉类/豆干制食品', '', '', '', 'default/cate.png', 1, 8, NULL);
INSERT INTO `baykeshop_baykeproductcategory` VALUES (11, '2023-05-19 03:13:49.784527', '2023-05-19 03:13:49.784527', 0, '饼干糕点', '', '', '', 'default/cate.png', 1, 8, NULL);
INSERT INTO `baykeshop_baykeproductcategory` VALUES (12, '2023-05-19 03:13:49.785524', '2023-05-19 03:13:49.785524', 0, '巧克力/糖果', '', '', '', 'default/cate.png', 1, 8, NULL);
INSERT INTO `baykeshop_baykeproductcategory` VALUES (13, '2023-05-19 03:49:57.119409', '2023-05-19 03:49:57.119409', 0, '花洒', '', '', '', 'default/cate.png', 1, 1, NULL);

-- ----------------------------
-- Table structure for baykeshop_baykeproductsku
-- ----------------------------
DROP TABLE IF EXISTS `baykeshop_baykeproductsku`;
CREATE TABLE `baykeshop_baykeproductsku`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `add_date` datetime(6) NOT NULL,
  `pub_date` datetime(6) NOT NULL,
  `is_del` tinyint(1) NOT NULL,
  `pic` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `price` decimal(8, 2) NOT NULL,
  `cost_price` decimal(10, 2) NOT NULL,
  `stock` int(10) UNSIGNED NOT NULL,
  `sales` int(10) UNSIGNED NOT NULL,
  `item_id` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `weight` smallint(5) UNSIGNED NOT NULL,
  `volume` smallint(5) UNSIGNED NOT NULL,
  `is_release` tinyint(1) NOT NULL,
  `site_id` int(11) NULL DEFAULT NULL,
  `spu_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `item_id`(`item_id`) USING BTREE,
  INDEX `baykeshop_baykeproductsku_site_id_5b944484_fk_django_site_id`(`site_id`) USING BTREE,
  INDEX `baykeshop_baykeprodu_spu_id_b214e0c0_fk_baykeshop`(`spu_id`) USING BTREE,
  CONSTRAINT `baykeshop_baykeprodu_spu_id_b214e0c0_fk_baykeshop` FOREIGN KEY (`spu_id`) REFERENCES `baykeshop_baykeproductspu` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `baykeshop_baykeproductsku_site_id_5b944484_fk_django_site_id` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 10 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of baykeshop_baykeproductsku
-- ----------------------------
INSERT INTO `baykeshop_baykeproductsku` VALUES (3, '2023-05-15 08:12:53.634000', '2023-05-19 02:15:33.227373', 0, 'product/2023/d028bd2c4cc02646d385995e545796bc.jpg', 128.00, 156.00, 147, 3, NULL, 0, 0, 1, NULL, 2);
INSERT INTO `baykeshop_baykeproductsku` VALUES (4, '2023-05-15 08:14:07.973000', '2023-05-19 03:22:02.543829', 0, 'product/2023/O1CN01z2RkuX1XLS3YFgZaW_2200771672907.jpg', 0.50, 398.00, 233, 3, NULL, 0, 0, 1, NULL, 3);
INSERT INTO `baykeshop_baykeproductsku` VALUES (5, '2023-05-19 03:19:26.672168', '2023-05-19 03:20:28.663738', 0, 'product/2023/milk.jpg', 89.90, 0.00, 9000, 0, NULL, 0, 0, 1, NULL, 4);
INSERT INTO `baykeshop_baykeproductsku` VALUES (6, '2023-05-19 03:35:17.296084', '2023-05-19 03:35:17.296084', 0, 'product/2023/巧克力.jpg', 12.00, 18.00, 360, 0, NULL, 0, 0, 1, NULL, 5);
INSERT INTO `baykeshop_baykeproductsku` VALUES (7, '2023-05-19 03:41:10.135646', '2023-05-19 03:41:10.135646', 0, 'product/2023/饼干.jpg', 15.00, 20.00, 186, 0, NULL, 0, 0, 1, NULL, 6);
INSERT INTO `baykeshop_baykeproductsku` VALUES (8, '2023-05-19 03:44:58.472745', '2023-05-19 06:31:07.055191', 0, 'product/2023/牛肉.jpg', 19.90, 36.00, 254, 2, NULL, 0, 0, 1, NULL, 7);
INSERT INTO `baykeshop_baykeproductsku` VALUES (9, '2023-05-19 03:49:38.564004', '2023-05-21 07:58:00.045125', 0, 'product/2023/花洒.jpg', 1379.00, 1579.00, 629, 1, NULL, 0, 0, 1, NULL, 8);

-- ----------------------------
-- Table structure for baykeshop_baykeproductsku_options
-- ----------------------------
DROP TABLE IF EXISTS `baykeshop_baykeproductsku_options`;
CREATE TABLE `baykeshop_baykeproductsku_options`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `baykeproductsku_id` bigint(20) NOT NULL,
  `baykeproductspecoption_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `baykeshop_baykeproductsk_baykeproductsku_id_bayke_bb21f5c6_uniq`(`baykeproductsku_id`, `baykeproductspecoption_id`) USING BTREE,
  INDEX `baykeshop_baykeprodu_baykeproductspecopti_0fd129d2_fk_baykeshop`(`baykeproductspecoption_id`) USING BTREE,
  CONSTRAINT `baykeshop_baykeprodu_baykeproductsku_id_d62150d5_fk_baykeshop` FOREIGN KEY (`baykeproductsku_id`) REFERENCES `baykeshop_baykeproductsku` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `baykeshop_baykeprodu_baykeproductspecopti_0fd129d2_fk_baykeshop` FOREIGN KEY (`baykeproductspecoption_id`) REFERENCES `baykeshop_baykeproductspecoption` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of baykeshop_baykeproductsku_options
-- ----------------------------

-- ----------------------------
-- Table structure for baykeshop_baykeproductspec
-- ----------------------------
DROP TABLE IF EXISTS `baykeshop_baykeproductspec`;
CREATE TABLE `baykeshop_baykeproductspec`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `add_date` datetime(6) NOT NULL,
  `pub_date` datetime(6) NOT NULL,
  `is_del` tinyint(1) NOT NULL,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `site_id` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `baykeshop_baykeproductspec_site_id_1a03492e_fk_django_site_id`(`site_id`) USING BTREE,
  CONSTRAINT `baykeshop_baykeproductspec_site_id_1a03492e_fk_django_site_id` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of baykeshop_baykeproductspec
-- ----------------------------
INSERT INTO `baykeshop_baykeproductspec` VALUES (1, '2023-04-28 05:43:39.809000', '2023-04-28 05:43:39.809000', 0, '颜色', NULL);
INSERT INTO `baykeshop_baykeproductspec` VALUES (2, '2023-05-04 01:46:52.085000', '2023-05-04 01:46:52.085000', 0, '大小', NULL);

-- ----------------------------
-- Table structure for baykeshop_baykeproductspecoption
-- ----------------------------
DROP TABLE IF EXISTS `baykeshop_baykeproductspecoption`;
CREATE TABLE `baykeshop_baykeproductspecoption`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `add_date` datetime(6) NOT NULL,
  `pub_date` datetime(6) NOT NULL,
  `is_del` tinyint(1) NOT NULL,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `site_id` int(11) NULL DEFAULT NULL,
  `spec_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `baykeshop_baykeprodu_site_id_5f2c6288_fk_django_si`(`site_id`) USING BTREE,
  INDEX `baykeshop_baykeprodu_spec_id_4edb69ce_fk_baykeshop`(`spec_id`) USING BTREE,
  CONSTRAINT `baykeshop_baykeprodu_site_id_5f2c6288_fk_django_si` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `baykeshop_baykeprodu_spec_id_4edb69ce_fk_baykeshop` FOREIGN KEY (`spec_id`) REFERENCES `baykeshop_baykeproductspec` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of baykeshop_baykeproductspecoption
-- ----------------------------
INSERT INTO `baykeshop_baykeproductspecoption` VALUES (1, '2023-04-28 05:43:39.810000', '2023-04-28 05:43:39.810000', 0, '红色', NULL, 1);
INSERT INTO `baykeshop_baykeproductspecoption` VALUES (2, '2023-04-28 05:43:39.811000', '2023-04-28 05:43:39.811000', 0, '绿色', NULL, 1);
INSERT INTO `baykeshop_baykeproductspecoption` VALUES (3, '2023-05-04 01:46:52.088000', '2023-05-04 01:46:52.088000', 0, 'L', NULL, 2);
INSERT INTO `baykeshop_baykeproductspecoption` VALUES (4, '2023-05-04 01:46:52.091000', '2023-05-04 01:46:52.091000', 0, 'XXL', NULL, 2);
INSERT INTO `baykeshop_baykeproductspecoption` VALUES (5, '2023-05-04 01:46:52.092000', '2023-05-04 01:46:52.092000', 0, 'XL', NULL, 2);

-- ----------------------------
-- Table structure for baykeshop_baykeproductspu
-- ----------------------------
DROP TABLE IF EXISTS `baykeshop_baykeproductspu`;
CREATE TABLE `baykeshop_baykeproductspu`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `add_date` datetime(6) NOT NULL,
  `pub_date` datetime(6) NOT NULL,
  `is_del` tinyint(1) NOT NULL,
  `title` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `desc` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `keywords` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `content` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `after_sale` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `pic` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `freight` decimal(5, 2) NOT NULL,
  `site_id` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `baykeshop_baykeproductspu_site_id_613e9e17_fk_django_site_id`(`site_id`) USING BTREE,
  CONSTRAINT `baykeshop_baykeproductspu_site_id_613e9e17_fk_django_site_id` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 9 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of baykeshop_baykeproductspu
-- ----------------------------
INSERT INTO `baykeshop_baykeproductspu` VALUES (2, '2023-05-15 08:12:53.625000', '2023-05-19 02:22:38.901932', 0, '索尼（SONY）WH-H910N 蓝牙降噪无线耳机 头戴式Hi-Res音质游戏耳机 手机耳机（hear系列 灰绿色 ）', '索尼（SONY）WH-H910N 蓝牙降噪无线耳机 头戴式Hi-Res音质游戏耳机 手机耳机（hear系列 灰绿色 ）', '耳机', '<p>索尼（SONY）WH-H910N 蓝牙降噪无线耳机 头戴式Hi-Res音质游戏耳机 手机耳机（hear系列 灰绿色 ）</p>', '', 'goods/2023/d028bd2c4cc02646d385995e545796bc.jpg', 2.00, NULL);
INSERT INTO `baykeshop_baykeproductspu` VALUES (3, '2023-05-15 08:14:07.965000', '2023-05-19 03:22:02.541805', 0, '测试商品', '测试商品', '测试商品', '<p>测试商品</p>', '测试商品', 'goods/2023/d7a95350679865a4c087e1b936d33e36.jpg', 1.00, NULL);
INSERT INTO `baykeshop_baykeproductspu` VALUES (4, '2023-05-19 03:19:26.564869', '2023-05-19 03:26:38.456033', 0, '【进口】纽仕兰3.5g蛋白质全脂纯牛奶250ml*24盒营养高钙早餐奶', '【进口】纽仕兰3.5g蛋白质全脂纯牛奶250ml*24盒营养高钙早餐奶', '进口、牛奶', '<p><img src=\"../../../../media/upload/8a133479e1a04402a568377ced8b091f.jpg\" alt=\"\" width=\"790\" height=\"1500\"></p>\r\n<p><img src=\"../../../../media/upload/29b204012a954c4ba09f5c74e5f913d9.jpg\" alt=\"\" width=\"790\" height=\"857\"></p>\r\n<p>&nbsp;</p>', '', 'goods/2023/milk.jpg', 12.00, NULL);
INSERT INTO `baykeshop_baykeproductspu` VALUES (5, '2023-05-19 03:35:17.190258', '2023-05-19 03:35:17.190258', 0, '百乐杯星球杯手指饼干26g*10杯儿童零食（代可可脂）', '百乐杯星球杯手指饼干26g*10杯儿童零食（代可可脂）', '巧克力', '<div class=\"Attrs--attrSection--2_G8xGa\" style=\"text-align: left;\"><span class=\"Attrs--attr--33ShB6X\" title=\"净含量：260g\" data-spm-anchor-id=\"pc_detail.27183998/evo365560b447259evo401275b518001.202206.i0.c2797dd6X9GovS\">净含量：260g&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</span><span class=\"Attrs--attr--33ShB6X\" title=\"品牌：百乐杯\">品牌：百乐杯&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</span><span class=\"Attrs--attr--33ShB6X\" title=\"系列：百乐杯\">系列：百乐杯</span></div>\r\n<div class=\"Attrs--attrSection--2_G8xGa\" style=\"text-align: left;\"><span class=\"Attrs--attr--33ShB6X\" title=\"形状：其他/other\">形状：其他/other&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</span><span class=\"Attrs--attr--33ShB6X\" title=\"产地：中国大陆\">产地：中国大陆&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class=\"Attrs--attr--33ShB6X\" title=\"省份：广东省\">省份：广东省</span></div>\r\n<div class=\"Attrs--attrSection--2_G8xGa\" style=\"text-align: left;\"><span class=\"Attrs--attr--33ShB6X\" title=\"城市：汕头市\">城市：汕头市&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</span><span class=\"Attrs--attr--33ShB6X\" title=\"包装方式：包装\">包装方式：包装&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class=\"Attrs--attr--33ShB6X\" title=\"是否含代可可脂含量≧5%：是\">是否含代可可脂含量≧5%：是</span></div>\r\n<div class=\"Attrs--attrSection--2_G8xGa\" style=\"text-align: left;\"><span class=\"Attrs--attr--33ShB6X\" title=\"巧克力制作工艺：非手工\">巧克力制作工艺：非手工&nbsp; </span><span class=\"Attrs--attr--33ShB6X\" title=\"蛋白质：5.8g/100g\">蛋白质：5.8g/100g&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</span><span class=\"Attrs--attr--33ShB6X\" title=\"能量：2218kJ/100g\">能量：2218kJ/100g</span></div>\r\n<div class=\"Attrs--attrSection--2_G8xGa\" style=\"text-align: left;\"><span class=\"Attrs--attr--33ShB6X\" title=\"脂肪：27.7g/100g\">脂肪：27.7g/100g&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</span><span class=\"Attrs--attr--33ShB6X\" title=\"碳水化合物：64.4g/100g\">碳水化合物：64.4g/100g&nbsp; &nbsp; &nbsp; &nbsp; </span><span class=\"Attrs--attr--33ShB6X\" title=\"钠：250mg/100g\">钠：250mg/100g</span></div>\r\n<div class=\"Attrs--attrSection--2_G8xGa\" style=\"text-align: left;\"><span class=\"Attrs--attr--33ShB6X\" title=\"钠：250mg/100g\"><img src=\"https://img.alicdn.com/imgextra/i2/2200629068218/O1CN016NcxYV2AZteCvkyZy_!!2200629068218-0-scmitem6000.jpg\" alt=\"\" width=\"800\" height=\"800\"></span></div>', '', 'goods/2023/巧克力.jpg', 2.00, NULL);
INSERT INTO `baykeshop_baykeproductspu` VALUES (6, '2023-05-19 03:41:10.035507', '2023-05-19 03:41:10.035507', 0, '奥利奥夹心饼干原味独立装休闲网红零食349g*1袋', '奥利奥夹心饼干原味独立装休闲网红零食349g*1袋', '饼干', '<div class=\"Attrs--attrSection--2_G8xGa\"><span class=\"Attrs--attr--33ShB6X\" title=\"原材料：小麦粉等\" data-spm-anchor-id=\"pc_detail.27183998/evo365560b447259evo401275b518001.202206.i0.5bcf7dd6PI223k\">原材料：小麦粉等&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</span><span class=\"Attrs--attr--33ShB6X\" title=\"卖点：独立小袋包装\">卖点：独立小袋包装&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class=\"Attrs--attr--33ShB6X\" title=\"品牌：奥利奥\">品牌：奥利奥</span></div>\r\n<div class=\"Attrs--attrSection--2_G8xGa\"><span class=\"Attrs--attr--33ShB6X\" title=\"糕点种类：夹心饼干\">糕点种类：夹心饼干&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</span><span class=\"Attrs--attr--33ShB6X\" title=\"是否添加蔗糖：是\">是否添加蔗糖：是&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class=\"Attrs--attr--33ShB6X\" title=\"口味：原味\">口味：原味</span></div>\r\n<div class=\"Attrs--attrSection--2_G8xGa\"><span class=\"Attrs--attr--33ShB6X\" title=\"净含量：349g\">净含量：349g&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</span><span class=\"Attrs--attr--33ShB6X\" title=\"保质期：12个月\">保质期：12个月&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</span><span class=\"Attrs--attr--33ShB6X\" title=\"品牌：奥利奥\">品牌：奥利奥</span></div>\r\n<div class=\"Attrs--attrSection--2_G8xGa\"><span class=\"Attrs--attr--33ShB6X\" title=\"系列：原味夹心饼干349g\">系列：原味夹心饼干349g&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</span><span class=\"Attrs--attr--33ShB6X\" title=\"产地：中国大陆\">产地：中国大陆&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</span><span class=\"Attrs--attr--33ShB6X\" title=\"省份：江苏省\">省份：江苏省</span></div>\r\n<div class=\"Attrs--attrSection--2_G8xGa\"><span class=\"Attrs--attr--33ShB6X\" title=\"包装方式：包装\">包装方式：包装&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class=\"Attrs--attr--33ShB6X\" title=\"是否进口：国产\">是否进口：国产&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</span><span class=\"Attrs--attr--33ShB6X\" title=\"蛋白质：0g/100g\">蛋白质：0g/100g</span></div>\r\n<div class=\"Attrs--attrSection--2_G8xGa\"><span class=\"Attrs--attr--33ShB6X\" title=\"能量：0kJ/100g\">能量：0kJ/100g&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class=\"Attrs--attr--33ShB6X\" title=\"脂肪：0g/100g\">脂肪：0g/100g&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class=\"Attrs--attr--33ShB6X\" title=\"碳水化合物：0g/100g\">碳水化合物：0g/100g</span></div>\r\n<div class=\"Attrs--attrSection--2_G8xGa\"><span class=\"Attrs--attr--33ShB6X\" title=\"钠：0mg/100g\">钠：0mg/100g</span></div>\r\n<div class=\"Attrs--attrSection--2_G8xGa\"><span class=\"Attrs--attr--33ShB6X\" title=\"钠：0mg/100g\"><img src=\"https://img.alicdn.com/imgextra/i3/2200633062791/O1CN01m9zPFI1WUK2uPyXZV_!!2200633062791-0-scmitem6000.jpg\" alt=\"\" width=\"750\" height=\"2292\"></span></div>\r\n<div class=\"Attrs--attrSection--2_G8xGa\"><span class=\"Attrs--attr--33ShB6X\" title=\"钠：0mg/100g\"><img src=\"https://img.alicdn.com/imgextra/i2/2200633062791/O1CN017sYKYW1WUK2rQzge7_!!2200633062791-0-scmitem6000.jpg\" alt=\"\"></span></div>', '', 'goods/2023/饼干.jpg', 2.00, NULL);
INSERT INTO `baykeshop_baykeproductspu` VALUES (7, '2023-05-19 03:44:58.077095', '2023-05-19 03:44:58.077095', 0, '三只松鼠牛肉干蜀香牛肉麻辣味100g*1袋零食解馋熟食特产小吃', '三只松鼠牛肉干蜀香牛肉麻辣味100g*1袋零食解馋熟食特产小吃', '牛肉干', '<p class=\"Attrs--attrSection--2_G8xGa\"><span class=\"Attrs--attr--33ShB6X\" title=\"食品工艺：卤味\" data-spm-anchor-id=\"pc_detail.27183998/evo365560b447259evo401275b518001.202206.i0.26e57dd6AGBPDn\">食品工艺：卤味&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</span><span class=\"Attrs--attr--33ShB6X\" title=\"包装方式：包装\">包装方式：包装&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</span><span class=\"Attrs--attr--33ShB6X\" title=\"净含量：100g\">净含量：100g</span></p>\r\n<div class=\"Attrs--attrSection--2_G8xGa\"><span class=\"Attrs--attr--33ShB6X\" title=\"品牌：Three Squirrels/三只松鼠\">品牌：Three Squirrels/三只松鼠&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</span><span class=\"Attrs--attr--33ShB6X\" title=\"系列：三只松鼠麻辣牛肉\">系列：三只松鼠麻辣牛肉&nbsp; &nbsp; &nbsp;</span><span class=\"Attrs--attr--33ShB6X\" title=\"产地：中国大陆\">产地：中国大陆</span></div>\r\n<p class=\"Attrs--attrSection--2_G8xGa\"><span class=\"Attrs--attr--33ShB6X\" title=\"省份：四川省\">省份：四川省&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class=\"Attrs--attr--33ShB6X\" title=\"城市：乐山市\">城市：乐山市&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</span><span class=\"Attrs--attr--33ShB6X\" title=\"肉类产品：其他/other\">肉类产品：其他/other</span></p>\r\n<p class=\"Attrs--attrSection--2_G8xGa\"><span class=\"Attrs--attr--33ShB6X\" title=\"肉类产品：其他/other\"><img src=\"https://img.alicdn.com/imgextra/i4/880734502/O1CN015ZMwne1j7xpj5eMo8_!!880734502-0-scmitem6000.jpg\" alt=\"\" width=\"790\" height=\"1225\"></span></p>\r\n<p class=\"Attrs--attrSection--2_G8xGa\"><span class=\"Attrs--attr--33ShB6X\" title=\"肉类产品：其他/other\"><img src=\"https://img.alicdn.com/imgextra/i2/2200628041767/O1CN01tXv1hw1OvKaSz4vhD_!!2200628041767-0-scmitem6000.jpg\" alt=\"\" width=\"790\" height=\"1225\"></span></p>\r\n<p class=\"Attrs--attrSection--2_G8xGa\">&nbsp;</p>', '', 'goods/2023/牛肉.jpg', 0.00, NULL);
INSERT INTO `baykeshop_baykeproductspu` VALUES (8, '2023-05-19 03:49:38.549035', '2023-05-19 03:50:21.769296', 0, '德国ZBMJK全铜白色枪灰色热熔暗装预埋淋浴花洒冷热水按键数显', '德国ZBMJK全铜白色枪灰色热熔暗装预埋淋浴花洒冷热水按键数显', '花洒', '<div class=\"Attrs--attrSection--2_G8xGa\"><span class=\"Attrs--attr--33ShB6X\" title=\"品牌：zBmJK\" data-spm-anchor-id=\"pc_detail.27183998/evo365560b447259evo401275b518001.202206.i0.69a27dd6EjxwyD\">品牌：zBmJK&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</span><span class=\"Attrs--attr--33ShB6X\" title=\"型号：HF9661\">型号：HF9661&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</span><span class=\"Attrs--attr--33ShB6X\" title=\"材质：全铜\">材质：全铜</span></div>\r\n<div class=\"Attrs--attrSection--2_G8xGa\"><span class=\"Attrs--attr--33ShB6X\" title=\"颜色分类：镀铬2功能数显 镀铬3功能数显 黑色2功能数显 黑色3功能数显 拉丝金2功能数显 拉丝金3功能数显 白色2功能数显 白色3功能数显 枪灰色2功能数显 枪灰色3功能数显\">颜色分类：镀铬2功能数显 镀铬3功能数显 黑色2功能数显 黑色3功能数显 拉丝金2功能数显 拉丝金3功能数显 白色2功能数显 白色3功能数显 枪灰色2功能数显 枪灰色3功能数显</span></div>\r\n<div class=\"Attrs--attrSection--2_G8xGa\"><span class=\"Attrs--attr--33ShB6X\" title=\"颜色分类：镀铬2功能数显 镀铬3功能数显 黑色2功能数显 黑色3功能数显 拉丝金2功能数显 拉丝金3功能数显 白色2功能数显 白色3功能数显 枪灰色2功能数显 枪灰色3功能数显\"><img src=\"https://img.alicdn.com/imgextra/i2/2214426167942/O1CN0113AYWf28XUMyl4DSG_!!2214426167942.jpg\" alt=\"\" width=\"1500\" height=\"2322\"></span></div>\r\n<div class=\"Attrs--attrSection--2_G8xGa\">&nbsp;</div>', '', 'goods/2023/花洒.jpg', 24.00, NULL);

-- ----------------------------
-- Table structure for baykeshop_baykeproductspu_cates
-- ----------------------------
DROP TABLE IF EXISTS `baykeshop_baykeproductspu_cates`;
CREATE TABLE `baykeshop_baykeproductspu_cates`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `baykeproductspu_id` bigint(20) NOT NULL,
  `baykeproductcategory_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `baykeshop_baykeproductsp_baykeproductspu_id_bayke_96888c07_uniq`(`baykeproductspu_id`, `baykeproductcategory_id`) USING BTREE,
  INDEX `baykeshop_baykeprodu_baykeproductcategory_82d95bdb_fk_baykeshop`(`baykeproductcategory_id`) USING BTREE,
  CONSTRAINT `baykeshop_baykeprodu_baykeproductcategory_82d95bdb_fk_baykeshop` FOREIGN KEY (`baykeproductcategory_id`) REFERENCES `baykeshop_baykeproductcategory` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `baykeshop_baykeprodu_baykeproductspu_id_e3f2a9f3_fk_baykeshop` FOREIGN KEY (`baykeproductspu_id`) REFERENCES `baykeshop_baykeproductspu` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 11 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of baykeshop_baykeproductspu_cates
-- ----------------------------
INSERT INTO `baykeshop_baykeproductspu_cates` VALUES (3, 2, 5);
INSERT INTO `baykeshop_baykeproductspu_cates` VALUES (4, 3, 5);
INSERT INTO `baykeshop_baykeproductspu_cates` VALUES (5, 4, 9);
INSERT INTO `baykeshop_baykeproductspu_cates` VALUES (6, 5, 12);
INSERT INTO `baykeshop_baykeproductspu_cates` VALUES (7, 6, 11);
INSERT INTO `baykeshop_baykeproductspu_cates` VALUES (8, 7, 10);
INSERT INTO `baykeshop_baykeproductspu_cates` VALUES (10, 8, 13);

-- ----------------------------
-- Table structure for baykeshop_baykesite
-- ----------------------------
DROP TABLE IF EXISTS `baykeshop_baykesite`;
CREATE TABLE `baykeshop_baykesite`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `add_date` datetime(6) NOT NULL,
  `pub_date` datetime(6) NOT NULL,
  `is_del` tinyint(1) NOT NULL,
  `site_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `site_title` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `site_header` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `beian` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `site_id` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `baykeshop_baykesite_site_id_6a32bdfa_fk_django_site_id`(`site_id`) USING BTREE,
  CONSTRAINT `baykeshop_baykesite_site_id_6a32bdfa_fk_django_site_id` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of baykeshop_baykesite
-- ----------------------------

-- ----------------------------
-- Table structure for baykeshop_baykeupload
-- ----------------------------
DROP TABLE IF EXISTS `baykeshop_baykeupload`;
CREATE TABLE `baykeshop_baykeupload`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `add_date` datetime(6) NOT NULL,
  `pub_date` datetime(6) NOT NULL,
  `is_del` tinyint(1) NOT NULL,
  `img` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `site_id` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `baykeshop_baykeupload_site_id_c75c7a33_fk_django_site_id`(`site_id`) USING BTREE,
  CONSTRAINT `baykeshop_baykeupload_site_id_c75c7a33_fk_django_site_id` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of baykeshop_baykeupload
-- ----------------------------
INSERT INTO `baykeshop_baykeupload` VALUES (1, '2023-05-19 03:16:50.717417', '2023-05-19 03:16:50.717417', 0, 'upload/0a5bd2f2e5954dbdb5cf4089b7580809.jpg', NULL);
INSERT INTO `baykeshop_baykeupload` VALUES (2, '2023-05-19 03:17:06.612524', '2023-05-19 03:17:06.612524', 0, 'upload/29b204012a954c4ba09f5c74e5f913d9.jpg', NULL);
INSERT INTO `baykeshop_baykeupload` VALUES (3, '2023-05-19 03:17:21.970448', '2023-05-19 03:17:21.970448', 0, 'upload/8a133479e1a04402a568377ced8b091f.jpg', NULL);

-- ----------------------------
-- Table structure for baykeshop_baykeuser
-- ----------------------------
DROP TABLE IF EXISTS `baykeshop_baykeuser`;
CREATE TABLE `baykeshop_baykeuser`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `add_date` datetime(6) NOT NULL,
  `pub_date` datetime(6) NOT NULL,
  `is_del` tinyint(1) NOT NULL,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `phone` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `email` varchar(254) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `avatar` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `balance` decimal(8, 2) NOT NULL,
  `desc` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `owner_id` int(11) NOT NULL,
  `site_id` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `owner_id`(`owner_id`) USING BTREE,
  UNIQUE INDEX `phone`(`phone`) USING BTREE,
  UNIQUE INDEX `email`(`email`) USING BTREE,
  INDEX `baykeshop_baykeuser_site_id_77b441be_fk_django_site_id`(`site_id`) USING BTREE,
  CONSTRAINT `baykeshop_baykeuser_owner_id_d2029b09_fk_auth_user_id` FOREIGN KEY (`owner_id`) REFERENCES `auth_user` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `baykeshop_baykeuser_site_id_77b441be_fk_django_site_id` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of baykeshop_baykeuser
-- ----------------------------
INSERT INTO `baykeshop_baykeuser` VALUES (1, '2023-05-16 15:52:17.429084', '2023-05-16 15:52:17.429084', 0, '', NULL, '7777777@qq.com', 'avatar/default.png', 0.00, '', 1, NULL);
INSERT INTO `baykeshop_baykeuser` VALUES (2, '2023-05-19 02:05:07.419251', '2023-05-19 06:31:09.554113', 0, '测试用户', '12345678911', '', 'avatar/wechat.png', 832.20, '', 2, NULL);
INSERT INTO `baykeshop_baykeuser` VALUES (3, '2023-05-21 07:13:11.624447', '2023-05-21 07:58:05.438098', 0, 'adm', NULL, '796433246@qq.com', 'avatar/default.png', 998620.00, '', 3, NULL);

-- ----------------------------
-- Table structure for baykeshop_baykeuserbalancelog
-- ----------------------------
DROP TABLE IF EXISTS `baykeshop_baykeuserbalancelog`;
CREATE TABLE `baykeshop_baykeuserbalancelog`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `add_date` datetime(6) NOT NULL,
  `pub_date` datetime(6) NOT NULL,
  `is_del` tinyint(1) NOT NULL,
  `amount` decimal(15, 2) NOT NULL,
  `change_status` smallint(5) UNSIGNED NULL DEFAULT NULL,
  `change_way` smallint(5) UNSIGNED NOT NULL,
  `owner_id` int(11) NOT NULL,
  `site_id` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `baykeshop_baykeuserbalancelog_owner_id_7de12bb5_fk_auth_user_id`(`owner_id`) USING BTREE,
  INDEX `baykeshop_baykeuserbalancelog_site_id_282b8345_fk_django_site_id`(`site_id`) USING BTREE,
  CONSTRAINT `baykeshop_baykeuserbalancelog_owner_id_7de12bb5_fk_auth_user_id` FOREIGN KEY (`owner_id`) REFERENCES `auth_user` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `baykeshop_baykeuserbalancelog_site_id_282b8345_fk_django_site_id` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of baykeshop_baykeuserbalancelog
-- ----------------------------
INSERT INTO `baykeshop_baykeuserbalancelog` VALUES (1, '2023-05-19 02:20:11.490900', '2023-05-19 02:20:11.490900', 0, 1000.00, 1, 2, 2, NULL);
INSERT INTO `baykeshop_baykeuserbalancelog` VALUES (2, '2023-05-19 02:20:19.315014', '2023-05-19 02:20:19.315014', 0, 128.00, 2, 3, 2, NULL);
INSERT INTO `baykeshop_baykeuserbalancelog` VALUES (3, '2023-05-19 04:20:22.783833', '2023-05-19 04:20:22.783833', 0, 19.90, 2, 3, 2, NULL);
INSERT INTO `baykeshop_baykeuserbalancelog` VALUES (4, '2023-05-19 06:31:09.563088', '2023-05-19 06:31:09.564088', 0, 19.90, 2, 3, 2, NULL);
INSERT INTO `baykeshop_baykeuserbalancelog` VALUES (5, '2023-05-21 07:58:05.451027', '2023-05-21 07:58:05.451027', 0, 1379.00, 2, 3, 3, NULL);

-- ----------------------------
-- Table structure for baykeshop_baykeverifycode
-- ----------------------------
DROP TABLE IF EXISTS `baykeshop_baykeverifycode`;
CREATE TABLE `baykeshop_baykeverifycode`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `add_date` datetime(6) NOT NULL,
  `pub_date` datetime(6) NOT NULL,
  `is_del` tinyint(1) NOT NULL,
  `email` varchar(254) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `code` varchar(4) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `site_id` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `baykeshop_baykeverifycode_site_id_01021837_fk_django_site_id`(`site_id`) USING BTREE,
  CONSTRAINT `baykeshop_baykeverifycode_site_id_01021837_fk_django_site_id` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of baykeshop_baykeverifycode
-- ----------------------------

-- ----------------------------
-- Table structure for django_admin_log
-- ----------------------------
DROP TABLE IF EXISTS `django_admin_log`;
CREATE TABLE `django_admin_log`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `object_repr` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `action_flag` smallint(5) UNSIGNED NOT NULL,
  `change_message` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `content_type_id` int(11) NULL DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `django_admin_log_content_type_id_c4bce8eb_fk_django_co`(`content_type_id`) USING BTREE,
  INDEX `django_admin_log_user_id_c564eba6_fk_auth_user_id`(`user_id`) USING BTREE,
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 31 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of django_admin_log
-- ----------------------------
INSERT INTO `django_admin_log` VALUES (65, '2023-05-21 08:04:05.164158', '64', '删除了“添加了“Home Banner/media/upload/2_zC7C4y7.jpg”。”。', 3, '', 1, 3);
INSERT INTO `django_admin_log` VALUES (66, '2023-05-21 08:04:05.171113', '63', '删除了“删除了“Home Banner/media/upload/%E7%94%BB%E6%9D%BF_1.jpg”。”。', 3, '', 1, 3);
INSERT INTO `django_admin_log` VALUES (67, '2023-05-21 08:04:05.174105', '62', '删除了“添加了“Home Banner/media/upload/1_Jm1PD6a.jpg”。”。', 3, '', 1, 3);
INSERT INTO `django_admin_log` VALUES (68, '2023-05-21 08:04:05.177097', '61', '删除了“添加了“Home Banner/media/upload/3_vakPJNZ.jpg”。”。', 3, '', 1, 3);
INSERT INTO `django_admin_log` VALUES (69, '2023-05-21 08:04:05.180089', '60', '删除了“添加了“testuser”。”。', 3, '', 1, 3);
INSERT INTO `django_admin_log` VALUES (70, '2023-05-21 08:04:05.182084', '59', '删除了“删除了“Django 提供了高级和低级的方法来帮助你管理分页数据”。”。', 3, '', 1, 3);
INSERT INTO `django_admin_log` VALUES (71, '2023-05-21 08:04:05.184078', '58', '删除了“修改了“20230519021533294”—没有字段被修改。”。', 3, '', 1, 3);
INSERT INTO `django_admin_log` VALUES (72, '2023-05-21 08:04:05.187075', '57', '删除了“修改了“testuser”—已修改Last login。 修改了 BaykeUser“testuser”的 余额。”。', 3, '', 1, 3);
INSERT INTO `django_admin_log` VALUES (73, '2023-05-21 08:04:05.189066', '56', '删除了“修改了“20230519021533294”—没有字段被修改。”。', 3, '', 1, 3);
INSERT INTO `django_admin_log` VALUES (74, '2023-05-21 08:04:05.192058', '55', '删除了“修改了“索尼（SONY）WH-H910N 蓝牙降噪无线耳机 头戴式Hi-Res音质游戏耳机 手机耳机（hear系列 灰绿色 ）”—已修改标题，描述，关键字，详情 和 售后服务。”。', 3, '', 1, 3);
INSERT INTO `django_admin_log` VALUES (75, '2023-05-21 08:04:05.194052', '54', '删除了“修改了“索尼（SONY）WH-H910N 蓝牙降噪无线耳机 头戴式Hi-Res音质游戏耳机 手机耳机（hear系列 灰绿色 ）”—已修改关键字。”。', 3, '', 1, 3);
INSERT INTO `django_admin_log` VALUES (76, '2023-05-21 08:04:05.197044', '53', '删除了“添加了“食品饮料”。”。', 3, '', 1, 3);
INSERT INTO `django_admin_log` VALUES (77, '2023-05-21 08:04:05.199038', '52', '删除了“添加了“【进口】纽仕兰3.5g蛋白质全脂纯牛奶250ml*24盒营养高钙早餐奶”。”。', 3, '', 1, 3);
INSERT INTO `django_admin_log` VALUES (78, '2023-05-21 08:04:05.202035', '51', '删除了“修改了“【进口】纽仕兰3.5g蛋白质全脂纯牛奶250ml*24盒营养高钙早餐奶”—修改了 BaykeProductSKU“【进口】纽仕兰3.5g蛋白质全脂纯牛奶250ml*24盒营养高钙早餐奶”的 库存。”。', 3, '', 1, 3);
INSERT INTO `django_admin_log` VALUES (79, '2023-05-21 08:04:05.204025', '50', '删除了“修改了“测试商品”—已修改标题，描述，关键字，详情 和 售后服务。”。', 3, '', 1, 3);
INSERT INTO `django_admin_log` VALUES (80, '2023-05-21 08:04:05.207017', '49', '删除了“修改了“测试商品”—修改了 BaykeProductSKU“测试商品”的 售价。”。', 3, '', 1, 3);
INSERT INTO `django_admin_log` VALUES (81, '2023-05-21 08:04:05.209026', '48', '删除了“修改了“【进口】纽仕兰3.5g蛋白质全脂纯牛奶250ml*24盒营养高钙早餐奶”—添加了 BaykeProductBanner“upload/milk_qb3j50n.jpg”。”。', 3, '', 1, 3);
INSERT INTO `django_admin_log` VALUES (82, '2023-05-21 08:04:05.211006', '47', '删除了“修改了“【进口】纽仕兰3.5g蛋白质全脂纯牛奶250ml*24盒营养高钙早餐奶”—修改了 BaykeProductBanner“upload/milk4_BnqmX9B.jpg”的 图片。 修改了 BaykeProductBanner“upload/milk5_PABoPCN.jpg”的 图片。”。', 3, '', 1, 3);
INSERT INTO `django_admin_log` VALUES (83, '2023-05-21 08:04:05.214003', '46', '删除了“修改了“【进口】纽仕兰3.5g蛋白质全脂纯牛奶250ml*24盒营养高钙早餐奶”—修改了 BaykeProductBanner“upload/milk_WVSvioN.jpg”的 图片。”。', 3, '', 1, 3);
INSERT INTO `django_admin_log` VALUES (84, '2023-05-21 08:04:05.215993', '45', '删除了“修改了“扫地机”—已修改标题。 修改了 BaykeProductSKU“扫地机”的 售价，原价，上架 和 规格值。”。', 3, '', 1, 3);
INSERT INTO `django_admin_log` VALUES (85, '2023-05-21 08:04:05.217987', '44', '删除了“修改了“扫地机”—修改了 BaykeProductSKU“扫地机”的 规格值。 修改了 BaykeProductSKU“扫地机”的 上架。”。', 3, '', 1, 3);
INSERT INTO `django_admin_log` VALUES (86, '2023-05-21 08:04:05.220980', '43', '删除了“添加了“百乐杯星球杯手指饼干26g*10杯儿童零食（代可可脂）”。”。', 3, '', 1, 3);
INSERT INTO `django_admin_log` VALUES (87, '2023-05-21 08:04:05.222974', '42', '删除了“添加了“奥利奥夹心饼干原味独立装休闲网红零食349g*1袋”。”。', 3, '', 1, 3);
INSERT INTO `django_admin_log` VALUES (88, '2023-05-21 08:04:05.225966', '41', '删除了“添加了“三只松鼠牛肉干蜀香牛肉麻辣味100g*1袋零食解馋熟食特产小吃”。”。', 3, '', 1, 3);
INSERT INTO `django_admin_log` VALUES (89, '2023-05-21 08:04:05.228958', '40', '删除了“添加了“德国ZBMJK全铜白色枪灰色热熔暗装预埋淋浴花洒冷热水按键数显”。”。', 3, '', 1, 3);
INSERT INTO `django_admin_log` VALUES (90, '2023-05-21 08:04:05.230954', '39', '删除了“修改了“家用电器”—添加了 BaykeProductCategory“花洒”。”。', 3, '', 1, 3);
INSERT INTO `django_admin_log` VALUES (91, '2023-05-21 08:04:05.233950', '38', '删除了“修改了“德国ZBMJK全铜白色枪灰色热熔暗装预埋淋浴花洒冷热水按键数显”—已修改商品分类。”。', 3, '', 1, 3);
INSERT INTO `django_admin_log` VALUES (92, '2023-05-21 08:04:05.235940', '37', '删除了“修改了“/faq/after/ -- 售后说明”—已修改Content。”。', 3, '', 1, 3);
INSERT INTO `django_admin_log` VALUES (93, '2023-05-21 08:04:05.238943', '36', '删除了“修改了“/faq/after/ -- 售后说明”—已修改Content。”。', 3, '', 1, 3);
INSERT INTO `django_admin_log` VALUES (94, '2023-05-21 08:04:05.240925', '35', '删除了“修改了“/faq/after/ -- 售后说明”—已修改Content。”。', 3, '', 1, 3);
INSERT INTO `django_admin_log` VALUES (95, '2023-05-21 08:04:05.242921', '34', '删除了“修改了“adm”—已修改Last login。 修改了 BaykeUser“adm”的 姓名 和 余额。”。', 3, '', 1, 3);
INSERT INTO `django_admin_log` VALUES (96, '2023-05-21 08:04:05.244916', '33', '删除了“删除了“扫地机”。”。', 3, '', 1, 3);

-- ----------------------------
-- Table structure for django_content_type
-- ----------------------------
DROP TABLE IF EXISTS `django_content_type`;
CREATE TABLE `django_content_type`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `model` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `django_content_type_app_label_model_76bd3d3b_uniq`(`app_label`, `model`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 37 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of django_content_type
-- ----------------------------
INSERT INTO `django_content_type` VALUES (1, 'admin', 'logentry');
INSERT INTO `django_content_type` VALUES (3, 'auth', 'group');
INSERT INTO `django_content_type` VALUES (2, 'auth', 'permission');
INSERT INTO `django_content_type` VALUES (4, 'auth', 'user');
INSERT INTO `django_content_type` VALUES (30, 'baykeshop', 'baykeaddress');
INSERT INTO `django_content_type` VALUES (29, 'baykeshop', 'baykearticle');
INSERT INTO `django_content_type` VALUES (28, 'baykeshop', 'baykearticlecategory');
INSERT INTO `django_content_type` VALUES (27, 'baykeshop', 'baykearticletag');
INSERT INTO `django_content_type` VALUES (26, 'baykeshop', 'baykebanner');
INSERT INTO `django_content_type` VALUES (25, 'baykeshop', 'baykecart');
INSERT INTO `django_content_type` VALUES (9, 'baykeshop', 'baykemenu');
INSERT INTO `django_content_type` VALUES (10, 'baykeshop', 'baykeorder');
INSERT INTO `django_content_type` VALUES (24, 'baykeshop', 'baykeordercomments');
INSERT INTO `django_content_type` VALUES (23, 'baykeshop', 'baykeordersku');
INSERT INTO `django_content_type` VALUES (22, 'baykeshop', 'baykepermission');
INSERT INTO `django_content_type` VALUES (21, 'baykeshop', 'baykeproductbanner');
INSERT INTO `django_content_type` VALUES (11, 'baykeshop', 'baykeproductcategory');
INSERT INTO `django_content_type` VALUES (20, 'baykeshop', 'baykeproductsku');
INSERT INTO `django_content_type` VALUES (12, 'baykeshop', 'baykeproductspec');
INSERT INTO `django_content_type` VALUES (19, 'baykeshop', 'baykeproductspecoption');
INSERT INTO `django_content_type` VALUES (18, 'baykeshop', 'baykeproductspu');
INSERT INTO `django_content_type` VALUES (17, 'baykeshop', 'baykesite');
INSERT INTO `django_content_type` VALUES (16, 'baykeshop', 'baykeupload');
INSERT INTO `django_content_type` VALUES (15, 'baykeshop', 'baykeuser');
INSERT INTO `django_content_type` VALUES (14, 'baykeshop', 'baykeuserbalancelog');
INSERT INTO `django_content_type` VALUES (13, 'baykeshop', 'baykeverifycode');
INSERT INTO `django_content_type` VALUES (5, 'contenttypes', 'contenttype');
INSERT INTO `django_content_type` VALUES (8, 'flatpages', 'flatpage');
INSERT INTO `django_content_type` VALUES (35, 'reversion', 'revision');
INSERT INTO `django_content_type` VALUES (36, 'reversion', 'version');
INSERT INTO `django_content_type` VALUES (6, 'sessions', 'session');
INSERT INTO `django_content_type` VALUES (7, 'sites', 'site');
INSERT INTO `django_content_type` VALUES (31, 'xadmin', 'bookmark');
INSERT INTO `django_content_type` VALUES (34, 'xadmin', 'log');
INSERT INTO `django_content_type` VALUES (32, 'xadmin', 'usersettings');
INSERT INTO `django_content_type` VALUES (33, 'xadmin', 'userwidget');

-- ----------------------------
-- Table structure for django_flatpage
-- ----------------------------
DROP TABLE IF EXISTS `django_flatpage`;
CREATE TABLE `django_flatpage`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `title` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `content` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `enable_comments` tinyint(1) NOT NULL,
  `template_name` varchar(70) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `registration_required` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `django_flatpage_url_41612362`(`url`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 8 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of django_flatpage
-- ----------------------------
INSERT INTO `django_flatpage` VALUES (1, '/about/', '关于我们', '<p>关于我们关于我们关于我们关于我们关于我们关于我们关于我们关于我们关于我们关于我们关于我们关于我们关于我们</p>\r\n<p><img src=\"../../../../../media/upload/1d57cdf6b26a4c2d8a9d6664156ce279.jpg\" alt=\"\" width=\"800\" height=\"800\"></p>', 0, '', 0);
INSERT INTO `django_flatpage` VALUES (2, '/faq/after/', '售后说明', '<div class=\"index-module_header_3qjZG\">\r\n<div class=\"index-module_title_1s0gC\">\r\n<p>超市消费者售后政策（总则）<br>第一章 总则<br>第一节 概述</p>\r\n<p>第一条 消费者在超市购买实物商品收货后，需进行售后服务，适用本售后服务政策。</p>\r\n<p>第二条 超市售后服务政策需遵循淘宝/平台规则要求，若淘宝平台规则调整，超市售后服务政策未及时调整导致存在差异，优先以淘宝平台规则要求为准。若超市售后政策更有利于消费者，则以超市售后政策要求为准。</p>\r\n<p>第三条 消费者通过淘宝平台系统、阿里旺旺、电子邮件、联系超市客服、联系供应商/品牌客服等方式发起的售后服务诉求，提供了在超市交易订单号后，都要予以受理。</p>\r\n<p>第二章 售后受理<br>第一节 受理期限</p>\r\n<p>第四条 消费者应在交易成功后的7天内提出售后申请，</p>\r\n<p>第五条 类目对售后受理时效有特殊规定的，依照类目的特殊规定。</p>\r\n<p>第二节 受理范围</p>\r\n<p>第六条 超市承诺符合以下情形，自消费者签收商品次日起7日内可以退货，15日内可以换货（若无换货能力支持退款给消费者），客户可在线提交售后申请办理退换货事宜，具体情形如下：</p>\r\n<p>（一）商品质量问题、商品存在性能故障或经证实为假冒商品；</p>\r\n<p>（二）商品描述不当、表面不一致情形；</p>\r\n<p>（三）其他原因，消费者个人原因需退换货。</p>\r\n<p>第七条 收货时间以第三方物流平台显示的实际到货日期第二日为准。</p>\r\n<p>第八条 以下根据商品性质不适宜退货，商品页面标注&ldquo;不支持无理由退货&rdquo;的商品可不支持消费者进行无理由退换货服务：</p>\r\n<p>（一）鲜活易腐类商品；</p>\r\n<p>（二）虚拟商品：卡券、数字化商品；</p>\r\n<p>（三）个人定做类商品；</p>\r\n<p>（四）已交付的保质期刊类、盲盒类商品；</p>\r\n<p>（五）拆封后易影响人身安全或者生命健康的商品，或拆封后易导致商品品质发生改变的商品；</p>\r\n<p>（六）一经激活或试用后价值贬损较大的商品；</p>\r\n<p>（七）销售时已明示的临近质保期的商品、有瑕疵的商品；</p>\r\n<p>（八）无法保证退回商品完好，且不影响二次销售的的商品（能够保持原有品质、功能，商品本身、配件、商标标识齐全的，视为商品完好）。</p>\r\n<p>第三章 售后审核<br>第一节 售后审核时效</p>\r\n<p>第九条 消费者提交售后申请后，超市需要在规定的时效内审核，并给出审核结果。若超出规定时效未审核，则系统自动提供退货地址给到消费者进行退货，审核时效规定如下：</p>\r\n<p>（一）因商品质量问题、商品信息描述不符、商品破损申请售后，超市需要在24H内审核；</p>\r\n<p>（二）其他原因申请售后，卖家/供应商需要在48H内审核。</p>\r\n<p>（三）若因特殊假节日或不可抗力因素有特殊时效规定的，以售后系统页面提示的审核时效为准。</p>\r\n<p>第十条 超市审核消费者的退款信息，发现消费者退款金额或退款原因填写错误，而拒绝此次售后申请，消费者可在5天内修改退款协议，修改后重新进入售后流程。</p>\r\n<p>&nbsp;</p>\r\n<p>第二节 商品质量问题、商品存在性能性故障或经证实为假冒商品审核规范</p>\r\n<p>第十一条 消费者主张商品存在质量问题系肉眼可识别的，申请售后时应提交相应凭证。否则超市可拒绝此次售后申请。消费者已提供凭证且经超市初步认定的，超市应按照法律规定或淘宝平台相关规则承担退货、更换、维修等义务。</p>\r\n<p>第十二条 消费者主张商品系假冒商品的，超市根据审核需要，有权要求供应商提供厂家的经销凭证、报关单据（进口商品）、产品合格证、商业发票、执行标准等相关凭证以证明商品来源或出厂合规，若供应商无法提供，交易支持退货退款。若供应商提供有效凭证，消费者仍主张商品系假冒商品的，则需及时提供有效的质检凭证或其他有效凭证，超市根据凭证信息判断假冒商品是否实属。</p>\r\n<p>第十三条 消费者主张商品存在质量问题系肉眼不可识别的性能性故障，经由生产厂家指定或特约售后服务中心检测确认，并出具检测报告或经超市售后确认属于商品质量问题，交易支持退货退款。若消费者当地无检测条件的，供应商需配合检测。</p>\r\n<p>第十四条 应超市要求，商品经消费者送检后证实为质量问题的，检测费用由超市承担，若被检商品因检测而被物流破坏导致无法退货或无退货价值的，交易支持退款。</p>\r\n<p>第十五条 非应超市要求，消费者仍将商品送检的，检测费用需消费者自行承担，特殊情形可进一步协商。</p>\r\n<p>第三节 商品描述不当、表面不一致情形审核规范</p>\r\n<p>第十六条 消费者主张商品存在描述不当系肉眼可识别的，申请售后时应提交相应凭证。超市根据消费者提供的凭证初步认定存在描述不当，交易支持退款。</p>\r\n<p>第十七条 消费者主张商品描述不当系肉眼不可识别的，超市将参照&ldquo;商品质量问题&rdquo;审核规范进行处理。</p>\r\n<p>第十八条 若消费者主张商品存在描述不当系无需使用，肉眼即可显著识别的，若商品完好，支持退货退款；若消费者已经使用且影响商品完好的，超市有权拒绝此次售后申请。</p>\r\n<p>第十九条 若商品或服务的描述存在违反广告法情形，或消费者需使用商品后方能察觉该商品描述不当的，交易支持退货退款。</p>\r\n<p>第二十条 消费者已证明商品签收时存在描述不当的，消费者可视商品性质及损失大小合理选择要求超市承担补寄、换货、退货等处理方式。</p>\r\n<p>第二十一条 消费者主张商品存在表面不一致的，应在承运人交付商品时，当场检视商品表面是否一致，若发现表面不一致，可予以拍照并拒签。若消费者未当面签收商品，或签收后发现表面不一致的，需在签收当日申请售后并提供相应凭证，超市初步认定存在表面不一致，交易支持退款。如因商品属性特殊难以快速检视，或特殊情形导致消费者不便于当日举证，超市可基于实际情况处理售后。</p>\r\n<p>第二十二条 消费者主张商品存在表面不一致，超市经与承运快递、仓库发货监控等能够证明消费者签收商品时不存在表面不一致的，消费者无法进一步提供证明，则超市可视情形拒绝此次售后申请。</p>\r\n<p>第四节 七天无理由退换货审核规范</p>\r\n<p>第二十三条 消费者在超市购物，自签收商品第二日起7日内（含7日），在保证商品完好的前提下，可申请7天无理由退货。</p>\r\n<p>第二十四条 商品完好指商品能够保持原有品质、功能，包括商品本身、配件及附带的商标吊牌、使用说明书等期权。消费者基于查验需要而打开商品包装，或者为确认商品的品质、功能而进行合理、适当的试用不影响商品的完好；但对超出查验和试用需要而使用商品，导致商品产生价值贬损较大的，视为商品不完好。</p>\r\n<p>（一）消费者应当确保退回商品和相关配（附）件（如吊牌、说明书、三包卡、入网卡等）齐全，并保持原有品质、功能，无受损、受污、刮开防伪、产生激活（授权）等情形，无难以恢复原状的外观类使用痕迹、不合理的个人数据使用痕迹；</p>\r\n<p>（二）商品包装说明：部分商品因包装特殊性，7天无理由退货需提供商品原包装，且包装需保持完整。例如：电子产品、家电类商品、灯具类商品、或包装价值较高（手表、瑞表、金银珠宝、首饰、贵重礼品等）等；</p>\r\n<p>（三）赠品遗失或破损、发票遗失不影响商品退货。赠品破损或遗失做折价处理，发票遗失由客户承担相应税款&ldquo;外包装&rdquo;是指：生产厂商原包装（最小销售单元），不含销售商或物流服务商自行二次封装的包装；</p>\r\n<p>（四）化妆品、个人护理用品、图书、婴儿尿片、音像制品等外包装被一次性密封的，不得拆封。&ldquo;密封&rdquo;是指：商品外包装被生产厂商加了封条（签）或整体塑（密）封的包装措施。</p>\r\n<p>第四章 消费者退货<br>第一节 退货规范</p>\r\n<p>第二十五条 超市/供应商应对自行填写的默认退货地址确保正确，交易达成退货协议后，若需要指定退货地址或多退货地址的，应征得消费者同意，否则，消费者可选择按淘宝平台系统给出的退货地址进行退货，退货后无法送达的风险由超市/供应商承担，交易支持退款给消费者。</p>\r\n<p>第二十六条 超市/供应商提供的退货地址应与发货地一致，未经买家同意不得为中国大陆以外地区。</p>\r\n<p>第二十七条 买卖双方达成退货协议的，消费者应在系统规定的退货时间内进行退货。消费者超时未退货，系统将关闭售后申请，如消费者需再次以相同原因要求退货的，超市可视情形处理。</p>\r\n<p>第二十八条 消费者可选择上门取件和自行寄出两种方式进行退货，若需要以其他形式退货，消费者需要与超市协商一致，否则产生的一切风险由消费者承担。</p>\r\n<p>第二十九条 若消费者选择自行寄出商品，应及时在淘宝平台系统内填写承运单号或告知卖家，供超市/供应商识别退货及查验商品。若超市/供应商签收商品时消费者仍未告知该承运单号，主张表面不一致情形的，需消费者联系承运快递举证。</p>\r\n<p>第三十条 消费者使用到付方式退货，应事先征得超市同意，否则超市拒收产生的风险由消费者承担。</p>\r\n<p>第三十一条 商品因质量问题、描述不当、签收时存在破损导致消费者合同目的不能实现的，消费者将退货商品交付承运人后，商品破损、损毁、灭失的风险由超市承担，交易支持退款。</p>\r\n<p>第三十二条 商品存在一定瑕疵但未影响消费者合同目的实现的，消费者将退货商品交付承运人后，商品破损的风险由超市承担，交易支持退款；若商品出现损毁、灭失情形的，超市可拒绝退款，消费者有权向承运人求偿。</p>\r\n<p>第二节 退货运费</p>\r\n<p>第三十三条 支持七天无理由退货的商品，消费者七天无理由退货或者无理由拒签的，退回运费由消费者承担。</p>\r\n<p>第三十四条 支持七天无理由换货的商品，消费者七天无理由换货的，由消费者承担换货所产生的所有运费。</p>\r\n<p>第三十五条 非消费者原因（如商品质量问题、描述不当、表面不一致等）等退换货，商品返回超市的运费由超市承担。</p>\r\n<p>第三十六条 消费者使用到付方式退货，事先未征得超市/供应商同意导致拒收，产生的二次退货运费由消费者承担。</p>\r\n<p>第三十七条 由消费者承担退货运费时，若超市/供应商提供的退货地址和商品页面中显示的发货地不一致，导致买家退货的运费高于按照该发货地址进行退货的运费，其差额由超市承担。</p>\r\n<p>第五章 仓库收货查验<br>第一节 收货规范</p>\r\n<p>第三十八条 仓库不得无理由拒收消费者退回的商品，因仓库不合理拒收产生的额外退货成本由超市承担。不合理拒收情形包含：</p>\r\n<p>（一）消费者符合七天无理由退换货情形，仓库以拆开外包装为由拒收退回商品；</p>\r\n<p>（二）消费者符合商品质量问题、描述不当、表面不一致情形退换货，仓库以商品质量问题为由拒收退回商品；</p>\r\n<p>第三十九条 仓库收货后需24H内完成查验，并上传查验信息至系统中。超市客服依据仓库收货查验信息为消费者处理退款，情形如下：</p>\r\n<p>（一）经仓库查验，消费者退货数量一致、商品符合退货情况，交易支持退款；</p>\r\n<p>（二）经仓库查验，消费者商品符合退货情况，但数量存在差异，超市客服与消费者协商折价退款；</p>\r\n<p>（三）经仓库查验，消费者退货数量一致，但商品不符合退货情况，超市客服基于商品实际退回的情况与消费者协商折价退款。</p>\r\n<p>第四十条 经仓库查验，收到的商品与实际客户申请售后描述不符且商品价值贬损较大而须原返给消费者，需在消费者收到退回商品后，拒绝消费者此次售后申请。</p>\r\n<p>&nbsp;</p>\r\n<p>第二节 实际退款金额</p>\r\n<p>第四十一条 自消费者上传寄回快递单号至系统240H后，超市仍未给出审核结果，则系统自动为客户退款。</p>\r\n<p>第四十二条 在商品退货时，需扣除购买该商品时通过评价或晒单或买返所获得的猫超卡及相应优惠，如相应优惠已使用，则从商品退款金额中扣除。</p>\r\n<p>第四十三条 有赠品的主商品发生退货时，需要将赠品一并提交退货返回，如赠品未退回，主商品无法全额退款。</p>\r\n</div>\r\n</div>', 0, '', 0);
INSERT INTO `django_flatpage` VALUES (3, '/faq/pay/', '支付问题', '支付问题支付问题支付问题支付问题支付问题支付问题支付问题支付问题支付问题支付问题支付问题支付问题支付问题支付问题支付问题支付问题支付问题支付问题支付问题支付问题支付问题支付问题支付问题支付问题支付问题支付问题支付问题支付问题支付问题支付问题支付问题支付问题', 0, '', 0);
INSERT INTO `django_flatpage` VALUES (4, '/newbie/flow/', '购物流程', '购物流程购物流程购物流程购物流程购物流程购物流程购物流程购物流程购物流程购物流程购物流程购物流程购物流程购物流程购物流程购物流程购物流程购物流程购物流程购物流程购物流程购物流程购物流程购物流程购物流程购物流程购物流程购物流程购物流程购物流程购物流程购物流程购物流程购物流程购物流程购物流程购物流程购物流程购物流程购物流程购物流程购物流程购物流程购物流程购物流程购物流程', 0, '', 0);
INSERT INTO `django_flatpage` VALUES (5, '/newbie/payment/', '支付方式', '支付方式支付方式支付方式支付方式支付方式支付方式支付方式支付方式支付方式支付方式支付方式支付方式支付方式支付方式支付方式支付方式支付方式支付方式支付方式支付方式支付方式支付方式支付方式支付方式支付方式支付方式支付方式支付方式支付方式支付方式支付方式支付方式支付方式支付方式支付方式支付方式支付方式支付方式支付方式支付方式支付方式支付方式支付方式支付方式支付方式支付方式支付方式支付方式支付方式支付方式', 0, '', 0);
INSERT INTO `django_flatpage` VALUES (6, '/serve/refund/', '退款流程', '退款流程退款流程退款流程退款流程退款流程退款流程退款流程退款流程退款流程退款流程退款流程退款流程退款流程退款流程退款流程退款流程退款流程退款流程退款流程退款流程退款流程退款流程退款流程退款流程退款流程退款流程退款流程退款流程退款流程退款流程退款流程退款流程退款流程退款流程退款流程退款流程退款流程退款流程退款流程退款流程退款流程退款流程退款流程', 0, '', 0);
INSERT INTO `django_flatpage` VALUES (7, '/serve/return/', '退货政策', '退货政策退货政策退货政策退货政策退货政策退货政策退货政策退货政策退货政策退货政策退货政策退货政策退货政策退货政策退货政策退货政策退货政策退货政策退货政策退货政策退货政策退货政策退货政策退货政策退货政策退货政策退货政策退货政策退货政策退货政策退货政策退货政策退货政策退货政策', 0, '', 0);

-- ----------------------------
-- Table structure for django_flatpage_sites
-- ----------------------------
DROP TABLE IF EXISTS `django_flatpage_sites`;
CREATE TABLE `django_flatpage_sites`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `flatpage_id` int(11) NOT NULL,
  `site_id` int(11) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `django_flatpage_sites_flatpage_id_site_id_0d29d9d1_uniq`(`flatpage_id`, `site_id`) USING BTREE,
  INDEX `django_flatpage_sites_site_id_bfd8ea84_fk_django_site_id`(`site_id`) USING BTREE,
  CONSTRAINT `django_flatpage_sites_flatpage_id_078bbc8b_fk_django_flatpage_id` FOREIGN KEY (`flatpage_id`) REFERENCES `django_flatpage` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `django_flatpage_sites_site_id_bfd8ea84_fk_django_site_id` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 8 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of django_flatpage_sites
-- ----------------------------
INSERT INTO `django_flatpage_sites` VALUES (1, 1, 1);
INSERT INTO `django_flatpage_sites` VALUES (2, 2, 1);
INSERT INTO `django_flatpage_sites` VALUES (3, 3, 1);
INSERT INTO `django_flatpage_sites` VALUES (4, 4, 1);
INSERT INTO `django_flatpage_sites` VALUES (5, 5, 1);
INSERT INTO `django_flatpage_sites` VALUES (6, 6, 1);
INSERT INTO `django_flatpage_sites` VALUES (7, 7, 1);

-- ----------------------------
-- Table structure for django_migrations
-- ----------------------------
DROP TABLE IF EXISTS `django_migrations`;
CREATE TABLE `django_migrations`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `app` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 29 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of django_migrations
-- ----------------------------
INSERT INTO `django_migrations` VALUES (1, 'contenttypes', '0001_initial', '2023-05-16 15:49:29.604632');
INSERT INTO `django_migrations` VALUES (2, 'auth', '0001_initial', '2023-05-16 15:49:30.548811');
INSERT INTO `django_migrations` VALUES (3, 'admin', '0001_initial', '2023-05-16 15:49:30.788426');
INSERT INTO `django_migrations` VALUES (4, 'admin', '0002_logentry_remove_auto_add', '2023-05-16 15:49:30.795407');
INSERT INTO `django_migrations` VALUES (5, 'admin', '0003_logentry_add_action_flag_choices', '2023-05-16 15:49:30.805412');
INSERT INTO `django_migrations` VALUES (6, 'contenttypes', '0002_remove_content_type_name', '2023-05-16 15:49:30.971229');
INSERT INTO `django_migrations` VALUES (7, 'auth', '0002_alter_permission_name_max_length', '2023-05-16 15:49:31.085923');
INSERT INTO `django_migrations` VALUES (8, 'auth', '0003_alter_user_email_max_length', '2023-05-16 15:49:31.153741');
INSERT INTO `django_migrations` VALUES (9, 'auth', '0004_alter_user_username_opts', '2023-05-16 15:49:31.161750');
INSERT INTO `django_migrations` VALUES (10, 'auth', '0005_alter_user_last_login_null', '2023-05-16 15:49:31.210616');
INSERT INTO `django_migrations` VALUES (11, 'auth', '0006_require_contenttypes_0002', '2023-05-16 15:49:31.214579');
INSERT INTO `django_migrations` VALUES (12, 'auth', '0007_alter_validators_add_error_messages', '2023-05-16 15:49:31.222558');
INSERT INTO `django_migrations` VALUES (13, 'auth', '0008_alter_user_username_max_length', '2023-05-16 15:49:31.281401');
INSERT INTO `django_migrations` VALUES (14, 'auth', '0009_alter_user_last_name_max_length', '2023-05-16 15:49:31.340243');
INSERT INTO `django_migrations` VALUES (15, 'auth', '0010_alter_group_name_max_length', '2023-05-16 15:49:31.418035');
INSERT INTO `django_migrations` VALUES (16, 'auth', '0011_update_proxy_permissions', '2023-05-16 15:49:31.427011');
INSERT INTO `django_migrations` VALUES (17, 'auth', '0012_alter_user_first_name_max_length', '2023-05-16 15:49:31.494862');
INSERT INTO `django_migrations` VALUES (18, 'sites', '0001_initial', '2023-05-16 15:49:31.513806');
INSERT INTO `django_migrations` VALUES (19, 'sites', '0002_alter_domain_unique', '2023-05-16 15:49:31.528773');
INSERT INTO `django_migrations` VALUES (20, 'baykeshop', '0001_initial', '2023-05-16 15:49:36.267844');
INSERT INTO `django_migrations` VALUES (21, 'flatpages', '0001_initial', '2023-05-16 15:49:36.457337');
INSERT INTO `django_migrations` VALUES (22, 'sessions', '0001_initial', '2023-05-16 15:49:36.513220');
INSERT INTO `django_migrations` VALUES (23, 'reversion', '0001_squashed_0004_auto_20160611_1202', '2023-05-20 08:49:38.644055');
INSERT INTO `django_migrations` VALUES (24, 'reversion', '0002_add_index_on_version_for_content_type_and_db', '2023-05-20 08:49:38.681953');
INSERT INTO `django_migrations` VALUES (25, 'xadmin', '0001_initial', '2023-05-20 08:49:39.081882');
INSERT INTO `django_migrations` VALUES (26, 'xadmin', '0002_log', '2023-05-20 08:49:39.267388');
INSERT INTO `django_migrations` VALUES (27, 'xadmin', '0003_auto_20160715_0100', '2023-05-20 08:49:39.417985');
INSERT INTO `django_migrations` VALUES (28, 'xadmin', '0004_alter_bookmark_id_alter_log_id_alter_usersettings_id_and_more', '2023-05-20 08:49:39.720177');

-- ----------------------------
-- Table structure for django_session
-- ----------------------------
DROP TABLE IF EXISTS `django_session`;
CREATE TABLE `django_session`  (
  `session_key` varchar(40) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `session_data` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`) USING BTREE,
  INDEX `django_session_expire_date_a5c62663`(`expire_date`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of django_session
-- ----------------------------
INSERT INTO `django_session` VALUES ('am47x1ljsmal97b62mn05c5alvsn6sr9', '.eJxVjMEOwiAQRP-FsyGl0MJ69N5vIAu7SNVAUtqT8d9tkx70OPPezFt43Nbst8aLn0lchRaX3y5gfHI5AD2w3KuMtazLHOShyJM2OVXi1-10_w4ytryvTUAb-xHROSDbRcOqC8hMDrXrB4IBAijLBKM2ylmdOCTFZPYUMYH4fAH42Thz:1q0dFf:MYZZyU2KX0_rCzZOuiwfg0mL2Ek68cHIraEdc36VNhY', '2023-06-04 07:13:11.614473');
INSERT INTO `django_session` VALUES ('ee4f53o00l6xlf99gse9jjyndpl3d0jh', '.eJxVjEEOgjAQRe_StWlmKG2tS_ecgcwwU4saSCisjHdXEha6_e-9_zI9bWvpt6pLP4q5GDSn341peOi0A7nTdJvtME_rMrLdFXvQartZ9Hk93L-DQrV868AO4KwBvGhKDTFIwhYbbR0zAhJCmzlEhpgQSDxHx-g0s-eQQzTvD8o6N34:1pzp6f:E49bYELjWohj08sWFtuP20AkJG7iLBKonPa_pzNe_tk', '2023-06-02 01:40:33.963825');

-- ----------------------------
-- Table structure for django_site
-- ----------------------------
DROP TABLE IF EXISTS `django_site`;
CREATE TABLE `django_site`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `domain` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `django_site_domain_a2e37b91_uniq`(`domain`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of django_site
-- ----------------------------
INSERT INTO `django_site` VALUES (1, 'example.com', 'example.com');

-- ----------------------------
-- Table structure for reversion_revision
-- ----------------------------
DROP TABLE IF EXISTS `reversion_revision`;
CREATE TABLE `reversion_revision`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_created` datetime(6) NOT NULL,
  `comment` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `user_id` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `reversion_revision_user_id_17095f45_fk_auth_user_id`(`user_id`) USING BTREE,
  INDEX `reversion_revision_date_created_96f7c20c`(`date_created`) USING BTREE,
  CONSTRAINT `reversion_revision_user_id_17095f45_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of reversion_revision
-- ----------------------------

-- ----------------------------
-- Table structure for reversion_version
-- ----------------------------
DROP TABLE IF EXISTS `reversion_version`;
CREATE TABLE `reversion_version`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `object_id` varchar(191) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `format` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `serialized_data` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `object_repr` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `revision_id` int(11) NOT NULL,
  `db` varchar(191) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `reversion_version_db_content_type_id_objec_b2c54f65_uniq`(`db`, `content_type_id`, `object_id`, `revision_id`) USING BTREE,
  INDEX `reversion_version_revision_id_af9f6a9d_fk_reversion_revision_id`(`revision_id`) USING BTREE,
  INDEX `reversion_v_content_f95daf_idx`(`content_type_id`, `db`) USING BTREE,
  CONSTRAINT `reversion_version_content_type_id_7d0ff25c_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `reversion_version_revision_id_af9f6a9d_fk_reversion_revision_id` FOREIGN KEY (`revision_id`) REFERENCES `reversion_revision` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of reversion_version
-- ----------------------------

-- ----------------------------
-- Table structure for xadmin_bookmark
-- ----------------------------
DROP TABLE IF EXISTS `xadmin_bookmark`;
CREATE TABLE `xadmin_bookmark`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `title` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `url_name` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `query` varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `is_share` tinyint(1) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `user_id` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `xadmin_bookmark_content_type_id_60941679_fk_django_co`(`content_type_id`) USING BTREE,
  INDEX `xadmin_bookmark_user_id_42d307fc_fk_auth_user_id`(`user_id`) USING BTREE,
  CONSTRAINT `xadmin_bookmark_content_type_id_60941679_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `xadmin_bookmark_user_id_42d307fc_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of xadmin_bookmark
-- ----------------------------

-- ----------------------------
-- Table structure for xadmin_log
-- ----------------------------
DROP TABLE IF EXISTS `xadmin_log`;
CREATE TABLE `xadmin_log`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `ip_addr` char(39) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `object_id` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `object_repr` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `action_flag` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `message` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `content_type_id` int(11) NULL DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `xadmin_log_content_type_id_2a6cb852_fk_django_content_type_id`(`content_type_id`) USING BTREE,
  INDEX `xadmin_log_user_id_bb16a176_fk_auth_user_id`(`user_id`) USING BTREE,
  CONSTRAINT `xadmin_log_content_type_id_2a6cb852_fk_django_content_type_id` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `xadmin_log_user_id_bb16a176_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of xadmin_log
-- ----------------------------

-- ----------------------------
-- Table structure for xadmin_usersettings
-- ----------------------------
DROP TABLE IF EXISTS `xadmin_usersettings`;
CREATE TABLE `xadmin_usersettings`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `key` varchar(256) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `value` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `xadmin_usersettings_user_id_edeabe4a_fk_auth_user_id`(`user_id`) USING BTREE,
  CONSTRAINT `xadmin_usersettings_user_id_edeabe4a_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of xadmin_usersettings
-- ----------------------------

-- ----------------------------
-- Table structure for xadmin_userwidget
-- ----------------------------
DROP TABLE IF EXISTS `xadmin_userwidget`;
CREATE TABLE `xadmin_userwidget`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `page_id` varchar(256) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `widget_type` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `value` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `xadmin_userwidget_user_id_c159233a_fk_auth_user_id`(`user_id`) USING BTREE,
  CONSTRAINT `xadmin_userwidget_user_id_c159233a_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of xadmin_userwidget
-- ----------------------------

SET FOREIGN_KEY_CHECKS = 1;
